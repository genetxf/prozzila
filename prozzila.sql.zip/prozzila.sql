-- phpMyAdmin SQL Dump
-- version 4.9.10
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jan 21, 2024 at 05:41 AM
-- Server version: 5.7.39
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prozzila`
--
CREATE DATABASE IF NOT EXISTS `prozzila` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `prozzila`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `admin_id` int(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`, `email`, `first_name`, `last_name`, `profile_picture`, `phone_number`, `address`) VALUES
(1, 'foyez', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'foyez@prozilla.com', NULL, NULL, 'foyez.jpg', NULL, NULL),
(3, 'test', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'test@email.com', NULL, NULL, NULL, NULL, NULL),
(4, 'foyezreg', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'testh@gmail.com', NULL, NULL, NULL, NULL, NULL),
(5, 'foyezd', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'test@gmail.com', NULL, NULL, NULL, NULL, NULL),
(6, 'testadmin', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'testadmin@gmail.com', NULL, NULL, NULL, NULL, NULL),
(7, 'newadmin', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'newadmin@gmail.com', NULL, NULL, NULL, NULL, NULL),
(8, 'testadmin2', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'testadmin@test.com', NULL, NULL, NULL, NULL, NULL),
(9, 'testadmin23', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'testadmin23@test.com', NULL, NULL, NULL, NULL, NULL),
(10, 'testadmin23fcx', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'testadmin23fd@test.com', NULL, NULL, NULL, NULL, NULL),
(11, 'test345', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'test345@test.com', NULL, NULL, NULL, NULL, NULL),
(12, 'sdfghj', '$2y$10$gNIvB0wF0XfipcX8VzlGCOwPnxhUzqcAglfZKzDJkn9W85ZoXHXHy', 'sdxfcgvbhn@fg.com', NULL, NULL, NULL, NULL, NULL),
(13, 'testadmin435', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'testadmin435@test.com', NULL, NULL, NULL, NULL, NULL),
(14, 'test765', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'test765@test.com', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
CREATE TABLE `assignment` (
  `id` int(255) NOT NULL,
  `task_id` int(255) DEFAULT NULL,
  `employee_id` int(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`id`, `task_id`, `employee_id`, `status`) VALUES
(1, 1, 1, NULL),
(3, 5, 1, NULL),
(4, 4, 132, NULL),
(7, 1, 88, NULL),
(9, 5, 130, NULL),
(10, 4, 130, NULL),
(11, 8, 130, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

DROP TABLE IF EXISTS `cards`;
CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`id`, `title`, `start`, `due_date`, `status`, `priority`, `description`) VALUES
(1, 'Website Design Card', '2024-01-08', '2024-01-13', 'progress', 'High', 'Website UI design.'),
(4, 'UI Design Card', '2024-01-08', '2024-01-13', 'todo', 'High', 'Mobile UI design'),
(5, 'Test Ui', '2024-01-09', '2024-01-25', 'approved', 'Low', 'Test'),
(6, 'Test new', '2024-01-10', '2024-01-18', 'review', 'Low', ' Test');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `about` text,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `name`, `email_id`, `contact_no`, `country`, `address`, `status`, `website`, `about`, `image`) VALUES
(1, 'TechVision Inc.', 'info@techvisioninc.com\r', '+123456796', 'USA', 'NY, USA', 'Active', 'techvisioninc.com\r', 'A tech Company with a vision, thats why we name it as Techvision.', 'logotech.jpg'),
(2, 'DevTech Solutions', 'info@devtechsolutions.com\r', '+898765786', 'Germany', 'Berlin, Germany', 'Active', 'devtechsolutions.com\r', 'We are the tech solutions for every developer.', 'Logonew1.jpg'),
(3, 'MarketGrowers Ltd.', 'info@marketgrowersltd.com\r', '+4917612345678', NULL, NULL, 'Active', 'marketgrowersltd.com\r', NULL, 'Logonew2.jpg'),
(4, 'TalentBoost Inc.', 'info@talentboostinc.com\r', '+390123456789', NULL, NULL, 'Active', 'talentboostinc.com\r', NULL, 'Logonew3.jpg'),
(5, 'StrategicSystems Ltd.', 'info@strategicsystemsltd.com\r', '+34987654321', NULL, NULL, 'Active', 'strategicsystemsltd.com\r', NULL, 'Logonew4.jpg'),
(6, 'DataWings Solutions', 'info@datawingssolutions.com\r', '+33123456789', NULL, NULL, 'Active', 'datawingssolutions.com\r', NULL, 'Logonew5.jpg'),
(7, 'FutureTech Enterprises', 'info@futuretechenterprises.com\r', '+31765432109', 'Denmark', 'Copenhagen, Denmark', 'Active', 'futuretechenterprises.com\r', 'Lets create some awesome tech for the Future.', 'Logonew6.jpg'),
(8, 'Techscribe Inc.', 'info@techscribeinc.com\r', '+1234567890', NULL, NULL, 'Active', 'techscribeinc.com\r', NULL, 'Logonew7.jpg'),
(9, 'NumbersUp Corporation', 'info@numbersupcorporation.com\r', '+4917600000000', NULL, NULL, 'Active', 'numbersupcorporation.com\r', NULL, 'Logonew8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `comment_id` int(255) NOT NULL,
  `employee_id` int(255) DEFAULT NULL,
  `entity_id` int(255) DEFAULT NULL,
  `entity_type` text,
  `comment_text` text,
  `comment_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `completed_tasks`
--

DROP TABLE IF EXISTS `completed_tasks`;
CREATE TABLE `completed_tasks` (
  `id` int(255) NOT NULL,
  `user_id` int(255) DEFAULT NULL,
  `card_id` int(255) DEFAULT NULL,
  `task_id` int(255) DEFAULT NULL,
  `completed_task` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `completed_tasks`
--

INSERT INTO `completed_tasks` (`id`, `user_id`, `card_id`, `task_id`, `completed_task`) VALUES
(36, 130, 2, 3, '2024-01-16 05:52:44'),
(37, 128, 1, 8, '2024-01-16 15:56:48'),
(38, 128, 1, 6, '2024-01-16 15:56:49'),
(39, 128, 1, 8, '2024-01-16 16:12:50'),
(43, 128, 5, 8, '2024-01-17 21:09:45'),
(44, 128, 5, 8, '2024-01-17 21:09:45'),
(45, 128, 5, 8, '2024-01-17 21:09:45'),
(46, 128, 5, 8, '2024-01-17 21:09:45');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int(255) NOT NULL,
  `task` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `task`, `attachment`, `date`) VALUES
(1, 'TestTaskProject', 'project10.jpg', '2024-01-20'),
(2, 'TestTaskProject', 'Prozzila A project and task management system Draft Update 190124.pdf', '2024-01-20'),
(3, 'TestTaskProject', 'ProZZila-Project-Management-System (2).png', '2024-01-20'),
(4, 'TestTaskProject', 'vecteezy_colorful-digital-technology-logo-design-vector-template_7610190_45.zip', '2024-01-20'),
(5, 'TestTaskProject', 'TMS presntation draft.docx', '2024-01-20'),
(6, 'TestTaskProject', 'ProZZila-Project-Management-System (3).png', '2024-01-20'),
(7, 'TestTaskProject', 'ProZZila-Project-Management-System.png', '2024-01-20'),
(8, 'TestTaskProject', 'Darft V1 Prozzila A project and task management system.pdf', '2024-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `department_id` int(255) NOT NULL,
  `department_name` varchar(255) NOT NULL,
  `department_code` varchar(255) DEFAULT NULL,
  `manager_id` int(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`, `department_code`, `manager_id`, `location`, `description`, `created_at`) VALUES
(1, 'Designing', 'DESIGN', NULL, 'Head Office', 'Responsible for graphic and UX/UI design', '2024-01-07 01:51:30'),
(2, 'Development', 'DEV', NULL, 'Head Office', 'Responsible for software development', '2024-01-07 01:51:30'),
(3, 'Marketing', 'MARKET', NULL, 'Head Office', 'Responsible for marketing strategies', '2024-01-07 01:51:30'),
(4, 'Human Resource', 'HR', NULL, 'Head Office', 'Responsible for managing human resources', '2024-01-07 01:51:30'),
(5, 'Managers', 'MANAGE', NULL, 'Head Office', 'Oversees different departments and teams', '2024-01-07 01:51:30'),
(6, 'Application', 'APP', NULL, 'Head Office', 'Handles applications and software deployment', '2024-01-07 01:51:30'),
(7, 'Support', 'SUPPORT', NULL, 'Head Office', 'Provides customer support', '2024-01-07 01:51:30'),
(8, 'IT', 'IT', NULL, 'Head Office', 'Manages information technology infrastructure', '2024-01-07 01:51:30'),
(9, 'Technical', 'TECH', NULL, 'Head Office', 'Handles technical aspects and solutions', '2024-01-07 01:51:30'),
(10, 'Accounts', 'ACCOUNTS', NULL, 'Head Office', 'Manages financial accounts', '2024-01-07 01:51:30'),
(12, 'UI Animation', 'UID55ES234', 130, 'Dhaka', 'UI animation', '2024-01-15 22:10:25');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `username`, `email`, `password`, `designation`) VALUES
(1, 'john', 'john.smith@example.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(2, 'emily', 'emily.johnson@example.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(3, 'michael', 'michael.williams@example.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(4, 'dimitri', 'dimitri.mueller@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(5, 'elena', 'elena.rossi@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(6, 'mateo', 'mateo.lopez@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(7, 'sophie', 'sophie.lefevre@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(8, 'hans', 'hans.jansen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(9, 'alex', 'alex.johnson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(10, 'sophia', 'sophia.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(11, 'liam', 'liam.martinez@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(12, 'mia', 'mia.lopez@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(13, 'noah', 'noah.schneider@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(14, 'emma', 'emma.andersen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(15, 'oliver', 'oliver.kovac@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(16, 'ava', 'ava.vasileva@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(17, 'william', 'william.bertaud@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(18, 'sophia', 'sophia.wagner@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(19, 'liam', 'liam.janssen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(20, 'isabella', 'isabella.ivanova@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(21, 'noah', 'noah.andersen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(22, 'olivia', 'olivia.moreau@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(23, 'lucas', 'lucas.novak@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(24, 'amelia', 'amelia.vasquez@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(25, 'arthur', 'arthur.kovalenko@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(26, 'eva', 'eva.jansen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(27, 'max', 'max.schmidt@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(28, 'lena', 'lena.dubois@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(29, 'finn', 'finn.sorensen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(30, 'lara', 'lara.kovac@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(31, 'ella', 'ella.andersson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(32, 'finn', 'finn.bachmann@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(33, 'hannah', 'hannah.carter@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(34, 'isaac', 'isaac.delgado@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(35, 'julia', 'julia.eriksson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(36, 'adam', 'adam.smith@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(37, 'sophie', 'sophie.jones@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(38, 'emma', 'emma.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(39, 'daniel', 'daniel.kovacs@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(40, 'sophia', 'sophia.mueller@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(41, 'eva', 'eva.hoffmann@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(42, 'sophie', 'sophie.gomes@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(43, 'henry', 'henry.bakker@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(44, 'luna', 'luna.rossi@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(45, 'sebastian', 'sebastian.kovac@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(46, 'sarah', 'sarah.johnson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(47, 'benjamin', 'benjamin.martinez@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(48, 'emma', 'emma.thompson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(49, 'ethan', 'ethan.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(50, 'sophia', 'sophia.nguyen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(51, 'liam', 'liam.schmidt@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(52, 'ava', 'ava.vasiliev@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(53, 'noah', 'noah.janssen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(54, 'mia', 'mia.bernard@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(55, 'oliver', 'oliver.hermansen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(56, 'maria', 'maria.hernandez@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(57, 'matteo', 'matteo.rossi@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(58, 'emma', 'emma.dubois@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(59, 'oliver', 'oliver.mueller@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(60, 'ava', 'ava.janssen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(61, 'liam', 'liam.andersen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(62, 'matteo', 'matteo.romano@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(63, 'eva', 'eva.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(64, 'oliver', 'oliver.schmidt@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(65, 'ava', 'ava.dubois@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(66, 'alice', 'alice.adams@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(67, 'benjamin', 'benjamin.bach@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(68, 'catherine', 'catherine.choi@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(69, 'daniel', 'daniel.diaz@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(70, 'emma', 'emma.eriksson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(71, 'eleanor', 'eleanor.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(72, 'henry', 'henry.schneider@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(73, 'sophie', 'sophie.janssen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(74, 'oliver', 'oliver.rossi@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(75, 'ava', 'ava.kovacs@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(76, 'benjamin', 'benjamin.klein@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(77, 'charlotte', 'charlotte.andersen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(78, 'daniel', 'daniel.dubois@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(79, 'emma', 'emma.johansson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(80, 'henry', 'henry.mueller@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(81, 'isabella', 'isabella.moreau@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(82, 'jacob', 'jacob.hansen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(83, 'lily', 'lily.vasileva@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(84, 'michael', 'michael.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(85, 'olivia', 'olivia.kovacs@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(86, 'eva', 'eva.andersson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(87, 'felix', 'felix.janssen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(88, 'grace', 'grace.moreau@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(89, 'henry', 'henry.kovac@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(90, 'isaac', 'isaac.schneider@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(91, 'julia', 'julia.hansen@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(92, 'kevin', 'kevin.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(93, 'lily', 'lily.bakker@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(94, 'mason', 'mason.vasilev@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(95, 'nora', 'nora.mueller@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(96, 'alice', 'alice.smith@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(97, 'ethan', 'ethan.johnson@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(98, 'sophie', 'sophie.garcia@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(99, 'sebastian', 'sebastian.kim@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(100, 'julia', 'julia.mueller@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(128, 'foyez', 'foyez@prozilla.com', NULL, NULL),
(130, 'mirza', 'mirza@prozilla.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(131, 'testtt', 'testtt@email.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(132, 'testempolyee', 'testemployee@gmail.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(133, 'new', 'new@gmail.com', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', NULL),
(134, 'test765', 'test765@test.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `invoice_id` varchar(255) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `payment` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `invoice_id`, `amount`, `invoice_date`, `due_date`, `payment`, `status`) VALUES
(1, '#INV-0478', 345, '2021-01-12', '2021-02-14', 345, 'Paid'),
(2, '#INV-1245', 834, '2021-01-12', '2021-02-14', 834, 'UnPaid'),
(3, '#INV-5280', 16753, '2021-01-21', '2021-01-15', 16753, 'Paid'),
(4, '#INV-2876', 297, '2021-02-05', '2021-02-21', 297, 'Paid'),
(5, '#INV-1986', 12897, '2021-01-01', '2021-02-24', 12897, 'UnPaid'),
(6, '#INV-2689', 29652, '2021-01-01', '2021-02-04', 29652, 'Paid'),
(7, '#INV-0298', 67298, '2021-02-02', '2021-02-24', 67298, 'Paid'),
(8, '#INV-0298', 87287, '2021-01-12', '2021-02-21', 87287, 'Paid'),
(9, '#INV-7618', 29674, '2021-02-04', '2021-03-14', 29674, 'UnPaid'),
(10, '#INV-0287', 25186, '2021-01-02', '2021-02-12', 25186, 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `message_id` int(255) NOT NULL,
  `sender_id` int(255) DEFAULT NULL,
  `receiver_id` int(255) DEFAULT NULL,
  `message_text` text,
  `message_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `old_complete`
--

DROP TABLE IF EXISTS `old_complete`;
CREATE TABLE `old_complete` (
  `id` int(255) NOT NULL,
  `user_id` int(255) DEFAULT NULL,
  `card_id` int(255) DEFAULT NULL,
  `task_id` int(255) DEFAULT NULL,
  `completed_task` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `old_complete`
--

INSERT INTO `old_complete` (`id`, `user_id`, `card_id`, `task_id`, `completed_task`) VALUES
(1, 128, 2, 2, '2024-01-15 09:47:10'),
(2, 128, 2, 2, '2024-01-15 10:06:12'),
(3, 128, 2, 2, '2024-01-15 10:09:23'),
(4, 128, 2, 2, '2024-01-15 10:09:37'),
(5, 128, 2, 2, '2024-01-15 10:10:07'),
(6, 128, 2, 2, '2024-01-15 10:17:03'),
(8, 128, 2, 5, '2024-01-15 08:58:54'),
(9, 128, 2, 5, '2024-01-15 09:45:52'),
(10, 128, 2, 5, '2024-01-15 10:09:33'),
(11, 128, 2, 5, '2024-01-15 10:10:12'),
(12, 128, 2, 5, '2024-01-15 10:17:15'),
(13, 128, 2, 5, '2024-01-15 10:26:00'),
(14, 128, 2, 5, '2024-01-15 10:26:54'),
(15, 128, 1, 6, '2024-01-15 10:31:32'),
(16, 128, 2, 3, '2024-01-15 08:51:45'),
(17, 128, 2, 3, '2024-01-15 08:51:45'),
(18, 128, 2, 3, '2024-01-15 08:58:41'),
(19, 128, 2, 3, '2024-01-15 09:36:31'),
(20, 128, 2, 3, '2024-01-15 09:43:45'),
(21, 128, 2, 3, '2024-01-15 09:44:31'),
(22, 128, 2, 3, '2024-01-15 09:45:28'),
(23, 128, 2, 3, '2024-01-15 10:09:29'),
(24, 128, 2, 3, '2024-01-15 10:10:10'),
(25, 128, 2, 3, '2024-01-15 10:17:09'),
(26, 128, 1, 3, '2024-01-15 10:35:08'),
(31, 128, 1, 6, '2024-01-15 10:41:55'),
(32, 128, 1, 6, '2024-01-15 10:43:03'),
(34, 128, 1, 3, '2024-01-15 10:36:22'),
(35, 128, 1, 3, '2024-01-15 10:46:13'),
(37, 128, 1, 3, '2024-01-15 10:47:42'),
(38, 130, 1, 5, '2024-01-15 14:08:21'),
(39, 130, 2, 3, '2024-01-15 14:16:03'),
(40, 130, 2, 6, '2024-01-15 14:16:08'),
(41, 130, 1, 8, '2024-01-16 16:35:00'),
(42, 130, 1, 6, '2024-01-16 17:44:42'),
(43, 130, 1, 5, '2024-01-15 14:08:24'),
(44, 130, 1, 5, '2024-01-15 14:12:55'),
(45, 130, 1, 5, '2024-01-16 18:02:56'),
(46, 130, 1, 5, '2024-01-16 18:09:36'),
(47, 130, 1, 5, '2024-01-16 18:09:48'),
(48, 130, 1, 5, '2024-01-16 18:10:11'),
(49, 130, 1, 5, '2024-01-16 18:10:26'),
(50, 130, 1, 5, '2024-01-16 18:14:19'),
(53, 130, 1, 6, '2024-01-16 17:45:15'),
(54, 130, 1, 6, '2024-01-16 17:46:38'),
(55, 130, 1, 6, '2024-01-16 17:47:05'),
(56, 130, 1, 6, '2024-01-16 18:09:48'),
(57, 130, 1, 6, '2024-01-16 18:10:11'),
(58, 130, 1, 6, '2024-01-16 18:10:30'),
(59, 130, 1, 6, '2024-01-16 18:14:19'),
(60, 130, 1, 5, '2024-01-16 18:16:06'),
(61, 130, 1, 5, '2024-01-16 18:17:30'),
(63, 130, 1, 5, '2024-01-16 18:18:59'),
(64, 130, 1, 5, '2024-01-16 18:21:11'),
(65, 130, 1, 6, '2024-01-16 18:16:14'),
(66, 130, 1, 6, '2024-01-16 18:21:12'),
(68, 130, 1, 5, '2024-01-16 18:29:25'),
(69, 130, 1, 5, '2024-01-16 18:38:05'),
(70, 130, 1, 5, '2024-01-16 18:38:59'),
(71, 130, 1, 5, '2024-01-16 18:39:13'),
(72, 130, 1, 5, '2024-01-16 18:39:42'),
(73, 130, 1, 5, '2024-01-16 18:40:22'),
(74, 130, 1, 5, '2024-01-16 18:41:09'),
(75, 130, 1, 5, '2024-01-16 18:42:24'),
(76, 130, 1, 5, '2024-01-16 18:43:48'),
(83, 130, 1, 6, '2024-01-16 18:43:49'),
(84, 130, 1, 4, '2024-01-16 18:45:07'),
(85, 130, 1, 6, '2024-01-16 18:47:43'),
(86, 130, 1, 8, '2024-01-16 16:50:19'),
(87, 130, 1, 8, '2024-01-16 16:53:49'),
(88, 130, 1, 8, '2024-01-16 17:35:40'),
(89, 130, 1, 8, '2024-01-16 17:35:44'),
(90, 130, 1, 8, '2024-01-16 17:39:34'),
(91, 130, 1, 8, '2024-01-16 17:45:25'),
(92, 130, 1, 8, '2024-01-16 17:47:06'),
(93, 130, 1, 8, '2024-01-16 18:00:58'),
(94, 130, 1, 8, '2024-01-16 18:09:49'),
(95, 130, 1, 8, '2024-01-16 18:10:32'),
(96, 130, 1, 8, '2024-01-16 18:48:44'),
(101, 130, 1, 5, '2024-01-16 20:08:10'),
(102, 130, 1, 6, '2024-01-16 20:08:17'),
(103, 130, 1, 5, '2024-01-16 20:12:47'),
(104, 130, 3, 5, '2024-01-17 20:58:04'),
(105, 130, 4, 4, '2024-01-17 21:03:22'),
(106, 130, 3, 4, '2024-01-17 21:07:37'),
(107, 130, 3, 1, '2024-01-17 21:13:55'),
(108, 130, 5, 8, '2024-01-17 21:14:10'),
(109, 130, 3, 5, '2024-01-17 21:14:26'),
(110, 130, 1, 6, '2024-01-19 05:13:33'),
(111, 130, 1, 6, '2024-01-19 05:13:33'),
(112, 130, 1, 6, '2024-01-19 05:13:33'),
(113, 130, 1, 6, '2024-01-19 05:13:33'),
(117, 130, 1, 6, '2024-01-19 05:13:33'),
(118, 130, 1, 6, '2024-01-19 05:13:33'),
(119, 130, 1, 6, '2024-01-19 05:13:33'),
(120, 130, 1, 6, '2024-01-19 05:13:33'),
(124, 130, 1, 6, '2024-01-19 05:13:33'),
(125, 130, 1, 6, '2024-01-19 05:13:33'),
(126, 130, 1, 6, '2024-01-19 05:13:33'),
(127, 130, 1, 6, '2024-01-19 05:13:33'),
(131, 130, 1, 6, '2024-01-19 05:13:33'),
(132, 130, 1, 6, '2024-01-19 05:13:33'),
(133, 130, 1, 6, '2024-01-19 05:13:33'),
(134, 130, 1, 6, '2024-01-19 05:13:33'),
(135, 128, 5, 9, '2024-01-20 15:11:41'),
(136, 128, 5, 9, '2024-01-20 15:11:41'),
(137, 128, 5, 9, '2024-01-20 15:11:41'),
(138, 128, 5, 9, '2024-01-20 15:11:41'),
(142, 128, 5, 9, '2024-01-20 15:11:41'),
(143, 128, 5, 9, '2024-01-20 15:11:41'),
(144, 128, 5, 9, '2024-01-20 15:11:41'),
(145, 128, 5, 9, '2024-01-20 15:11:41'),
(149, 128, 5, 9, '2024-01-20 15:11:41'),
(150, 128, 5, 9, '2024-01-20 15:11:41'),
(151, 128, 5, 9, '2024-01-20 15:11:41'),
(152, 128, 5, 9, '2024-01-20 15:11:41'),
(156, 128, 5, 9, '2024-01-20 15:11:41'),
(157, 128, 5, 9, '2024-01-20 15:11:41'),
(158, 128, 5, 9, '2024-01-20 15:11:41'),
(159, 128, 5, 9, '2024-01-20 15:11:41'),
(163, 128, 1, 4, '2024-01-20 15:10:46'),
(164, 128, 1, 4, '2024-01-20 15:10:46'),
(165, 128, 1, 4, '2024-01-20 15:10:46'),
(166, 128, 1, 4, '2024-01-20 15:10:46'),
(167, 128, 6, 4, '2024-01-20 15:14:11'),
(168, 128, 6, 4, '2024-01-20 15:14:11'),
(169, 128, 6, 4, '2024-01-20 15:14:11'),
(170, 128, 6, 4, '2024-01-20 15:14:11'),
(178, 128, 1, 4, '2024-01-20 15:10:46'),
(179, 128, 1, 4, '2024-01-20 15:10:46'),
(180, 128, 1, 4, '2024-01-20 15:10:46'),
(181, 128, 1, 4, '2024-01-20 15:10:46'),
(182, 128, 6, 4, '2024-01-20 15:14:11'),
(183, 128, 6, 4, '2024-01-20 15:14:11'),
(184, 128, 6, 4, '2024-01-20 15:14:11'),
(185, 128, 6, 4, '2024-01-20 15:14:11'),
(193, 128, 1, 4, '2024-01-20 15:10:46'),
(194, 128, 1, 4, '2024-01-20 15:10:46'),
(195, 128, 1, 4, '2024-01-20 15:10:46'),
(196, 128, 1, 4, '2024-01-20 15:10:46'),
(197, 128, 6, 4, '2024-01-20 15:14:11'),
(198, 128, 6, 4, '2024-01-20 15:14:11'),
(199, 128, 6, 4, '2024-01-20 15:14:11'),
(200, 128, 6, 4, '2024-01-20 15:14:11'),
(208, 128, 1, 1, '2024-01-15 09:48:07'),
(209, 128, 1, 1, '2024-01-15 10:09:57'),
(210, 128, 3, 1, '2024-01-17 21:09:54'),
(211, 128, 3, 1, '2024-01-17 21:09:54'),
(212, 128, 3, 1, '2024-01-17 21:09:54'),
(213, 128, 3, 1, '2024-01-17 21:09:54'),
(214, 128, 3, 1, '2024-01-17 21:27:24'),
(215, 128, 3, 1, '2024-01-17 21:27:24'),
(216, 128, 3, 1, '2024-01-17 21:27:24'),
(217, 128, 3, 1, '2024-01-17 21:27:24'),
(218, 128, 4, 1, '2024-01-20 15:15:19'),
(219, 128, 4, 1, '2024-01-20 15:15:19'),
(220, 128, 4, 1, '2024-01-20 15:15:19'),
(221, 128, 4, 1, '2024-01-20 15:15:19'),
(223, 128, 1, 1, '2024-01-15 09:48:07'),
(224, 128, 1, 1, '2024-01-15 10:09:57'),
(225, 128, 3, 1, '2024-01-17 21:09:54'),
(226, 128, 3, 1, '2024-01-17 21:09:54'),
(227, 128, 3, 1, '2024-01-17 21:09:54'),
(228, 128, 3, 1, '2024-01-17 21:09:54'),
(229, 128, 3, 1, '2024-01-17 21:27:24'),
(230, 128, 3, 1, '2024-01-17 21:27:24'),
(231, 128, 3, 1, '2024-01-17 21:27:24'),
(232, 128, 3, 1, '2024-01-17 21:27:24'),
(233, 128, 4, 1, '2024-01-20 15:15:19'),
(234, 128, 4, 1, '2024-01-20 15:15:19'),
(235, 128, 4, 1, '2024-01-20 15:15:19'),
(236, 128, 4, 1, '2024-01-20 15:15:19'),
(238, 128, 1, 1, '2024-01-15 09:48:07'),
(239, 128, 1, 1, '2024-01-15 10:09:57'),
(240, 128, 3, 1, '2024-01-17 21:09:54'),
(241, 128, 3, 1, '2024-01-17 21:09:54'),
(242, 128, 3, 1, '2024-01-17 21:09:54'),
(243, 128, 3, 1, '2024-01-17 21:09:54'),
(244, 128, 3, 1, '2024-01-17 21:27:24'),
(245, 128, 3, 1, '2024-01-17 21:27:24'),
(246, 128, 3, 1, '2024-01-17 21:27:24'),
(247, 128, 3, 1, '2024-01-17 21:27:24'),
(248, 128, 4, 1, '2024-01-20 15:15:19'),
(249, 128, 4, 1, '2024-01-20 15:15:19'),
(250, 128, 4, 1, '2024-01-20 15:15:19'),
(251, 128, 4, 1, '2024-01-20 15:15:19'),
(253, 128, 1, 1, '2024-01-15 09:48:07'),
(254, 128, 1, 1, '2024-01-15 10:09:57'),
(255, 128, 3, 1, '2024-01-17 21:09:54'),
(256, 128, 3, 1, '2024-01-17 21:09:54'),
(257, 128, 3, 1, '2024-01-17 21:09:54'),
(258, 128, 3, 1, '2024-01-17 21:09:54'),
(259, 128, 3, 1, '2024-01-17 21:27:24'),
(260, 128, 3, 1, '2024-01-17 21:27:24'),
(261, 128, 3, 1, '2024-01-17 21:27:24'),
(262, 128, 3, 1, '2024-01-17 21:27:24'),
(263, 128, 4, 1, '2024-01-20 15:15:19'),
(264, 128, 4, 1, '2024-01-20 15:15:19'),
(265, 128, 4, 1, '2024-01-20 15:15:19'),
(266, 128, 4, 1, '2024-01-20 15:15:19'),
(268, 128, 6, 4, '2024-01-20 15:16:30'),
(269, 128, 6, 4, '2024-01-20 15:16:30'),
(270, 128, 6, 4, '2024-01-20 15:16:30'),
(271, 128, 6, 4, '2024-01-20 15:16:30'),
(272, 128, 2, 4, '2024-01-20 15:30:20'),
(273, 128, 2, 4, '2024-01-20 15:30:20'),
(274, 128, 2, 4, '2024-01-20 15:30:20'),
(275, 128, 2, 4, '2024-01-20 15:30:20'),
(283, 128, 6, 4, '2024-01-20 15:16:30'),
(284, 128, 6, 4, '2024-01-20 15:16:30'),
(285, 128, 6, 4, '2024-01-20 15:16:30'),
(286, 128, 6, 4, '2024-01-20 15:16:30'),
(287, 128, 2, 4, '2024-01-20 15:30:20'),
(288, 128, 2, 4, '2024-01-20 15:30:20'),
(289, 128, 2, 4, '2024-01-20 15:30:20'),
(290, 128, 2, 4, '2024-01-20 15:30:20'),
(298, 128, 6, 4, '2024-01-20 15:16:30'),
(299, 128, 6, 4, '2024-01-20 15:16:30'),
(300, 128, 6, 4, '2024-01-20 15:16:30'),
(301, 128, 6, 4, '2024-01-20 15:16:30'),
(302, 128, 2, 4, '2024-01-20 15:30:20'),
(303, 128, 2, 4, '2024-01-20 15:30:20'),
(304, 128, 2, 4, '2024-01-20 15:30:20'),
(305, 128, 2, 4, '2024-01-20 15:30:20'),
(313, 128, 6, 4, '2024-01-20 15:16:30'),
(314, 128, 6, 4, '2024-01-20 15:16:30'),
(315, 128, 6, 4, '2024-01-20 15:16:30'),
(316, 128, 6, 4, '2024-01-20 15:16:30'),
(317, 128, 2, 4, '2024-01-20 15:30:20'),
(318, 128, 2, 4, '2024-01-20 15:30:20'),
(319, 128, 2, 4, '2024-01-20 15:30:20'),
(320, 128, 2, 4, '2024-01-20 15:30:20'),
(328, 128, 4, 1, '2024-01-20 15:18:37'),
(329, 128, 4, 1, '2024-01-20 15:18:37'),
(330, 128, 4, 1, '2024-01-20 15:18:37'),
(331, 128, 4, 1, '2024-01-20 15:18:37'),
(332, 128, 4, 1, '2024-01-20 15:25:15'),
(333, 128, 4, 1, '2024-01-20 15:25:15'),
(334, 128, 4, 1, '2024-01-20 15:25:15'),
(335, 128, 4, 1, '2024-01-20 15:25:15'),
(336, 128, 1, 1, '2024-01-20 15:33:20'),
(337, 128, 1, 1, '2024-01-20 15:33:20'),
(338, 128, 1, 1, '2024-01-20 15:33:20'),
(339, 128, 1, 1, '2024-01-20 15:33:20'),
(343, 128, 4, 1, '2024-01-20 15:18:37'),
(344, 128, 4, 1, '2024-01-20 15:18:37'),
(345, 128, 4, 1, '2024-01-20 15:18:37'),
(346, 128, 4, 1, '2024-01-20 15:18:37'),
(347, 128, 4, 1, '2024-01-20 15:25:15'),
(348, 128, 4, 1, '2024-01-20 15:25:15'),
(349, 128, 4, 1, '2024-01-20 15:25:15'),
(350, 128, 4, 1, '2024-01-20 15:25:15'),
(351, 128, 1, 1, '2024-01-20 15:33:20'),
(352, 128, 1, 1, '2024-01-20 15:33:20'),
(353, 128, 1, 1, '2024-01-20 15:33:20'),
(354, 128, 1, 1, '2024-01-20 15:33:20'),
(358, 128, 4, 1, '2024-01-20 15:18:37'),
(359, 128, 4, 1, '2024-01-20 15:18:37'),
(360, 128, 4, 1, '2024-01-20 15:18:37'),
(361, 128, 4, 1, '2024-01-20 15:18:37'),
(362, 128, 4, 1, '2024-01-20 15:25:15'),
(363, 128, 4, 1, '2024-01-20 15:25:15'),
(364, 128, 4, 1, '2024-01-20 15:25:15'),
(365, 128, 4, 1, '2024-01-20 15:25:15'),
(366, 128, 1, 1, '2024-01-20 15:33:20'),
(367, 128, 1, 1, '2024-01-20 15:33:20'),
(368, 128, 1, 1, '2024-01-20 15:33:20'),
(369, 128, 1, 1, '2024-01-20 15:33:20'),
(373, 128, 4, 1, '2024-01-20 15:18:37'),
(374, 128, 4, 1, '2024-01-20 15:18:37'),
(375, 128, 4, 1, '2024-01-20 15:18:37'),
(376, 128, 4, 1, '2024-01-20 15:18:37'),
(377, 128, 4, 1, '2024-01-20 15:25:15'),
(378, 128, 4, 1, '2024-01-20 15:25:15'),
(379, 128, 4, 1, '2024-01-20 15:25:15'),
(380, 128, 4, 1, '2024-01-20 15:25:15'),
(381, 128, 1, 1, '2024-01-20 15:33:20'),
(382, 128, 1, 1, '2024-01-20 15:33:20'),
(383, 128, 1, 1, '2024-01-20 15:33:20'),
(384, 128, 1, 1, '2024-01-20 15:33:20'),
(388, 130, 6, 8, '2024-01-20 15:37:26'),
(389, 130, 6, 8, '2024-01-20 15:37:26'),
(390, 130, 6, 8, '2024-01-20 15:37:26'),
(391, 130, 6, 8, '2024-01-20 15:37:26'),
(395, 130, 6, 8, '2024-01-20 15:37:26'),
(396, 130, 6, 8, '2024-01-20 15:37:26'),
(397, 130, 6, 8, '2024-01-20 15:37:26'),
(398, 130, 6, 8, '2024-01-20 15:37:26'),
(402, 128, 2, 2, '2024-01-15 10:17:22'),
(403, 128, 4, 2, '2024-01-20 15:50:55'),
(404, 128, 4, 2, '2024-01-20 15:50:55'),
(405, 128, 4, 2, '2024-01-20 15:50:55'),
(406, 128, 4, 2, '2024-01-20 15:50:55'),
(409, 128, 2, 2, '2024-01-15 10:17:22'),
(410, 128, 4, 2, '2024-01-20 15:50:55'),
(411, 128, 4, 2, '2024-01-20 15:50:55'),
(412, 128, 4, 2, '2024-01-20 15:50:55'),
(413, 128, 4, 2, '2024-01-20 15:50:55'),
(416, 128, 2, 2, '2024-01-15 10:17:22'),
(417, 128, 4, 2, '2024-01-20 15:50:55'),
(418, 128, 4, 2, '2024-01-20 15:50:55'),
(419, 128, 4, 2, '2024-01-20 15:50:55'),
(420, 128, 4, 2, '2024-01-20 15:50:55'),
(423, 128, 2, 2, '2024-01-15 10:17:22'),
(424, 128, 4, 2, '2024-01-20 15:50:55'),
(425, 128, 4, 2, '2024-01-20 15:50:55'),
(426, 128, 4, 2, '2024-01-20 15:50:55'),
(427, 128, 4, 2, '2024-01-20 15:50:55'),
(430, 128, 1, 5, '2024-01-15 10:27:56'),
(431, 128, 2, 5, '2024-01-15 10:42:01'),
(432, 128, 3, 5, '2024-01-17 21:09:55'),
(433, 128, 3, 5, '2024-01-17 21:09:55'),
(434, 128, 3, 5, '2024-01-17 21:09:55'),
(435, 128, 3, 5, '2024-01-17 21:09:55'),
(436, 128, 1, 5, '2024-01-20 14:57:23'),
(437, 128, 1, 5, '2024-01-20 14:57:23'),
(438, 128, 1, 5, '2024-01-20 14:57:23'),
(439, 128, 1, 5, '2024-01-20 14:57:23'),
(440, 128, 1, 5, '2024-01-20 14:57:43'),
(441, 128, 1, 5, '2024-01-20 14:57:43'),
(442, 128, 1, 5, '2024-01-20 14:57:43'),
(443, 128, 1, 5, '2024-01-20 14:57:43'),
(444, 128, 1, 5, '2024-01-20 15:10:29'),
(445, 128, 1, 5, '2024-01-20 15:10:29'),
(446, 128, 1, 5, '2024-01-20 15:10:29'),
(447, 128, 1, 5, '2024-01-20 15:10:29'),
(448, 128, 1, 5, '2024-01-20 15:10:47'),
(449, 128, 1, 5, '2024-01-20 15:10:47'),
(450, 128, 1, 5, '2024-01-20 15:10:47'),
(451, 128, 1, 5, '2024-01-20 15:10:47'),
(452, 128, 1, 5, '2024-01-20 15:18:27'),
(453, 128, 1, 5, '2024-01-20 15:18:27'),
(454, 128, 1, 5, '2024-01-20 15:18:27'),
(455, 128, 1, 5, '2024-01-20 15:18:27'),
(456, 128, 1, 5, '2024-01-20 15:24:55'),
(457, 128, 1, 5, '2024-01-20 15:24:55'),
(458, 128, 1, 5, '2024-01-20 15:24:55'),
(459, 128, 1, 5, '2024-01-20 15:24:55'),
(460, 128, 4, 5, '2024-01-20 15:54:11'),
(461, 128, 4, 5, '2024-01-20 15:54:11'),
(462, 128, 4, 5, '2024-01-20 15:54:11'),
(463, 128, 4, 5, '2024-01-20 15:54:11'),
(493, 128, 1, 5, '2024-01-15 10:27:56'),
(494, 128, 2, 5, '2024-01-15 10:42:01'),
(495, 128, 3, 5, '2024-01-17 21:09:55'),
(496, 128, 3, 5, '2024-01-17 21:09:55'),
(497, 128, 3, 5, '2024-01-17 21:09:55'),
(498, 128, 3, 5, '2024-01-17 21:09:55'),
(499, 128, 1, 5, '2024-01-20 14:57:23'),
(500, 128, 1, 5, '2024-01-20 14:57:23'),
(501, 128, 1, 5, '2024-01-20 14:57:23'),
(502, 128, 1, 5, '2024-01-20 14:57:23'),
(503, 128, 1, 5, '2024-01-20 14:57:43'),
(504, 128, 1, 5, '2024-01-20 14:57:43'),
(505, 128, 1, 5, '2024-01-20 14:57:43'),
(506, 128, 1, 5, '2024-01-20 14:57:43'),
(507, 128, 1, 5, '2024-01-20 15:10:29'),
(508, 128, 1, 5, '2024-01-20 15:10:29'),
(509, 128, 1, 5, '2024-01-20 15:10:29'),
(510, 128, 1, 5, '2024-01-20 15:10:29'),
(511, 128, 1, 5, '2024-01-20 15:10:47'),
(512, 128, 1, 5, '2024-01-20 15:10:47'),
(513, 128, 1, 5, '2024-01-20 15:10:47'),
(514, 128, 1, 5, '2024-01-20 15:10:47'),
(515, 128, 1, 5, '2024-01-20 15:18:27'),
(516, 128, 1, 5, '2024-01-20 15:18:27'),
(517, 128, 1, 5, '2024-01-20 15:18:27'),
(518, 128, 1, 5, '2024-01-20 15:18:27'),
(519, 128, 1, 5, '2024-01-20 15:24:55'),
(520, 128, 1, 5, '2024-01-20 15:24:55'),
(521, 128, 1, 5, '2024-01-20 15:24:55'),
(522, 128, 1, 5, '2024-01-20 15:24:55'),
(523, 128, 4, 5, '2024-01-20 15:54:11'),
(524, 128, 4, 5, '2024-01-20 15:54:11'),
(525, 128, 4, 5, '2024-01-20 15:54:11'),
(526, 128, 4, 5, '2024-01-20 15:54:11'),
(556, 128, 1, 5, '2024-01-15 10:27:56'),
(557, 128, 2, 5, '2024-01-15 10:42:01'),
(558, 128, 3, 5, '2024-01-17 21:09:55'),
(559, 128, 3, 5, '2024-01-17 21:09:55'),
(560, 128, 3, 5, '2024-01-17 21:09:55'),
(561, 128, 3, 5, '2024-01-17 21:09:55'),
(562, 128, 1, 5, '2024-01-20 14:57:23'),
(563, 128, 1, 5, '2024-01-20 14:57:23'),
(564, 128, 1, 5, '2024-01-20 14:57:23'),
(565, 128, 1, 5, '2024-01-20 14:57:23'),
(566, 128, 1, 5, '2024-01-20 14:57:43'),
(567, 128, 1, 5, '2024-01-20 14:57:43'),
(568, 128, 1, 5, '2024-01-20 14:57:43'),
(569, 128, 1, 5, '2024-01-20 14:57:43'),
(570, 128, 1, 5, '2024-01-20 15:10:29'),
(571, 128, 1, 5, '2024-01-20 15:10:29'),
(572, 128, 1, 5, '2024-01-20 15:10:29'),
(573, 128, 1, 5, '2024-01-20 15:10:29'),
(574, 128, 1, 5, '2024-01-20 15:10:47'),
(575, 128, 1, 5, '2024-01-20 15:10:47'),
(576, 128, 1, 5, '2024-01-20 15:10:47'),
(577, 128, 1, 5, '2024-01-20 15:10:47'),
(578, 128, 1, 5, '2024-01-20 15:18:27'),
(579, 128, 1, 5, '2024-01-20 15:18:27'),
(580, 128, 1, 5, '2024-01-20 15:18:27'),
(581, 128, 1, 5, '2024-01-20 15:18:27'),
(582, 128, 1, 5, '2024-01-20 15:24:55'),
(583, 128, 1, 5, '2024-01-20 15:24:55'),
(584, 128, 1, 5, '2024-01-20 15:24:55'),
(585, 128, 1, 5, '2024-01-20 15:24:55'),
(586, 128, 4, 5, '2024-01-20 15:54:11'),
(587, 128, 4, 5, '2024-01-20 15:54:11'),
(588, 128, 4, 5, '2024-01-20 15:54:11'),
(589, 128, 4, 5, '2024-01-20 15:54:11'),
(619, 128, 1, 5, '2024-01-15 10:27:56'),
(620, 128, 2, 5, '2024-01-15 10:42:01'),
(621, 128, 3, 5, '2024-01-17 21:09:55'),
(622, 128, 3, 5, '2024-01-17 21:09:55'),
(623, 128, 3, 5, '2024-01-17 21:09:55'),
(624, 128, 3, 5, '2024-01-17 21:09:55'),
(625, 128, 1, 5, '2024-01-20 14:57:23'),
(626, 128, 1, 5, '2024-01-20 14:57:23'),
(627, 128, 1, 5, '2024-01-20 14:57:23'),
(628, 128, 1, 5, '2024-01-20 14:57:23'),
(629, 128, 1, 5, '2024-01-20 14:57:43'),
(630, 128, 1, 5, '2024-01-20 14:57:43'),
(631, 128, 1, 5, '2024-01-20 14:57:43'),
(632, 128, 1, 5, '2024-01-20 14:57:43'),
(633, 128, 1, 5, '2024-01-20 15:10:29'),
(634, 128, 1, 5, '2024-01-20 15:10:29'),
(635, 128, 1, 5, '2024-01-20 15:10:29'),
(636, 128, 1, 5, '2024-01-20 15:10:29'),
(637, 128, 1, 5, '2024-01-20 15:10:47'),
(638, 128, 1, 5, '2024-01-20 15:10:47'),
(639, 128, 1, 5, '2024-01-20 15:10:47'),
(640, 128, 1, 5, '2024-01-20 15:10:47'),
(641, 128, 1, 5, '2024-01-20 15:18:27'),
(642, 128, 1, 5, '2024-01-20 15:18:27'),
(643, 128, 1, 5, '2024-01-20 15:18:27'),
(644, 128, 1, 5, '2024-01-20 15:18:27'),
(645, 128, 1, 5, '2024-01-20 15:24:55'),
(646, 128, 1, 5, '2024-01-20 15:24:55'),
(647, 128, 1, 5, '2024-01-20 15:24:55'),
(648, 128, 1, 5, '2024-01-20 15:24:55'),
(649, 128, 4, 5, '2024-01-20 15:54:11'),
(650, 128, 4, 5, '2024-01-20 15:54:11'),
(651, 128, 4, 5, '2024-01-20 15:54:11'),
(652, 128, 4, 5, '2024-01-20 15:54:11'),
(682, 128, 4, 5, '2024-01-20 15:58:25'),
(683, 128, 4, 5, '2024-01-20 15:58:25'),
(684, 128, 4, 5, '2024-01-20 15:58:25'),
(685, 128, 4, 5, '2024-01-20 15:58:25'),
(689, 128, 4, 5, '2024-01-20 15:58:25'),
(690, 128, 4, 5, '2024-01-20 15:58:25'),
(691, 128, 4, 5, '2024-01-20 15:58:25'),
(692, 128, 4, 5, '2024-01-20 15:58:25'),
(696, 128, 4, 5, '2024-01-20 15:58:25'),
(697, 128, 4, 5, '2024-01-20 15:58:25'),
(698, 128, 4, 5, '2024-01-20 15:58:25'),
(699, 128, 4, 5, '2024-01-20 15:58:25'),
(703, 128, 4, 5, '2024-01-20 15:58:25'),
(704, 128, 4, 5, '2024-01-20 15:58:25'),
(705, 128, 4, 5, '2024-01-20 15:58:25'),
(706, 128, 4, 5, '2024-01-20 15:58:25'),
(710, 130, 1, 9, '2024-01-20 21:14:00'),
(711, 130, 1, 9, '2024-01-20 21:14:00'),
(712, 130, 1, 9, '2024-01-20 21:14:00'),
(713, 130, 1, 9, '2024-01-20 21:14:00'),
(717, 130, 1, 9, '2024-01-20 21:14:00'),
(718, 130, 1, 9, '2024-01-20 21:14:00'),
(719, 130, 1, 9, '2024-01-20 21:14:00'),
(720, 130, 1, 9, '2024-01-20 21:14:00'),
(724, 130, 1, 9, '2024-01-20 21:14:00'),
(725, 130, 1, 9, '2024-01-20 21:14:00'),
(726, 130, 1, 9, '2024-01-20 21:14:00'),
(727, 130, 1, 9, '2024-01-20 21:14:00'),
(731, 130, 1, 9, '2024-01-20 21:14:00'),
(732, 130, 1, 9, '2024-01-20 21:14:00'),
(733, 130, 1, 9, '2024-01-20 21:14:00'),
(734, 130, 1, 9, '2024-01-20 21:14:00'),
(735, 130, 4, 2, '2024-01-20 23:05:29'),
(736, 130, 4, 2, '2024-01-20 23:05:29'),
(737, 130, 4, 2, '2024-01-20 23:05:29'),
(738, 130, 4, 2, '2024-01-20 23:05:29'),
(742, 130, 4, 2, '2024-01-20 23:05:29'),
(743, 130, 4, 2, '2024-01-20 23:05:29'),
(744, 130, 4, 2, '2024-01-20 23:05:29'),
(745, 130, 4, 2, '2024-01-20 23:05:29');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `payment_id` varchar(255) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `payment_id`, `amount`, `payment_type`, `due_date`, `status`) VALUES
(1, 'PAY-0478', 345, 'Cash', '2021-01-12', 'Paid'),
(2, 'PAY-0329', 897, 'Card', '2021-02-16', 'Paid'),
(3, 'PAY-0298', 298, 'Cash', '2021-03-05', 'UnPaid'),
(4, 'PAY-0560', 839, 'Online Payment', '2021-04-12', 'UnPaid'),
(5, 'PAY-0927', 9238, 'Cash', '2021-02-05', 'Paid'),
(6, 'PAY-2091', 11342, 'Online Payment', '2021-03-12', 'Paid'),
(7, 'PAY-1342', 82341, 'Cash', '2021-02-13', 'Paid'),
(8, 'PAY-1387', 9238, 'Card', '2021-02-12', 'Paid'),
(9, 'PAY-3298', 12765, 'Cash', '2021-03-25', 'UnPaid'),
(10, 'PAY-2125', 35250, 'Online Payment', '2021-03-16', 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `permission_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `resource_type` varchar(255) NOT NULL,
  `permission_level` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permission_id`, `user_id`, `resource_type`, `permission_level`) VALUES
(1, 3, 'comments', '3'),
(2, 2, 'permissions', '0'),
(3, 1, 'permissions', '0'),
(4, 89, 'permissions', '0'),
(5, 99, 'projects', '1'),
(6, 51, 'assignment', '2'),
(7, 83, 'tasks', '3'),
(8, 3, 'comments', '3'),
(9, 1, 'comments', '3'),
(10, 3, 'comments', '3'),
(11, 89, 'profiles', '1'),
(12, 1, 'admins', '1'),
(13, 1, 'assignment', '1'),
(14, 108, 'permissions', '3'),
(15, 0, '', '2');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
CREATE TABLE `profiles` (
  `id` int(255) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `about` varchar(255) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `termination_date` date DEFAULT NULL,
  `salary` double DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `marital_status` varchar(255) DEFAULT NULL,
  `emergency_contact_name` varchar(255) DEFAULT NULL,
  `emergency_contact_number` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `first_name`, `last_name`, `email`, `phone_number`, `picture`, `address`, `about`, `hire_date`, `termination_date`, `salary`, `gender`, `marital_status`, `emergency_contact_name`, `emergency_contact_number`, `designation`) VALUES
(1, 'John', 'Smith', 'john.smith@example.com', '123-456-7890', '', '123 Main St', 'Anytown', '2023-01-01', NULL, 60000, 'Male', 'Married', 'Jane Smith', '987-654-3210', NULL),
(2, 'Emily', 'Johnson', 'emily.johnson@example.com', '234-567-8901', '', '456 Elm St', 'Smallville', '2022-03-10', NULL, 55000, 'Female', 'Single', 'Jack Johnson', '876-543-2109', NULL),
(3, 'Michael', 'Williams', 'michael.williams@example.com', '345-678-9012', '', '789 Oak St', 'Metro City', '2024-02-20', NULL, 65000, 'Male', 'Married', 'Sarah Williams', '765-432-1098', NULL),
(4, 'Dimitri', 'Müller', 'dimitri.mueller@prozilla.com', '+4917612345678', '', '123 Oak St', 'Berlin', '2022-01-01', NULL, 65000, 'Male', 'Single', 'Anika Müller', '+4917612345679', NULL),
(5, 'Elena', 'Rossi', 'elena.rossi@prozilla.com', '+390123456789', '', '456 Maple Ave', 'Rome', '2023-03-01', NULL, 60000, 'Female', 'Married', 'Giovanni Rossi', '+390123456780', NULL),
(6, 'Mateo', 'López', 'mateo.lopez@prozilla.com', '+34987654321', '', '789 Elm St', 'Madrid', '2024-05-10', NULL, 70000, 'Male', 'Divorced', 'Carmen López', '+34987654322', NULL),
(7, 'Sophie', 'Lefèvre', 'sophie.lefevre@prozilla.com', '+33123456789', '', '567 Pine St', 'Paris', '2021-12-15', NULL, 55000, 'Female', 'Single', 'Lucas Lefèvre', '+33123456780', NULL),
(8, 'Hans', 'Jansen', 'hans.jansen@prozilla.com', '+31765432109', '', '890 Cedar St', 'Amsterdam', '2023-08-20', NULL, 75000, 'Male', 'Married', 'Maria Jansen', '+31765432110', NULL),
(9, 'Alex', 'Johnson', 'alex.johnson@prozilla.com', '+1234567890', '', '123 Main St', 'Anytown', '2022-01-01', NULL, 65000, 'Male', 'Single', 'Jennifer Lee', '+4445556666', NULL),
(10, 'Sophia', 'Garcia', 'sophia.garcia@prozilla.com', '+4917600000000', '', '456 Oak St', 'Berlin', '2023-03-01', NULL, 60000, 'Female', 'Married', 'Anika Müller', '+4917612345679', NULL),
(11, 'Liam', 'Martinez', 'liam.martinez@prozilla.com', '+390000000000', '', '789 Maple Ave', 'Rome', '2024-05-10', NULL, 70000, 'Male', 'Divorced', 'Giovanni Rossi', '+390123456789', NULL),
(12, 'Mia', 'Lopez', 'mia.lopez@prozilla.com', '+34987654321', '', '890 Elm St', 'Madrid', '2021-12-15', NULL, 55000, 'Female', 'Single', 'Carmen López', '+34987654322', NULL),
(13, 'Noah', 'Schneider', 'noah.schneider@prozilla.com', '+3176543210', '', '567 Pine St', 'Paris', '2023-08-20', NULL, 75000, 'Male', 'Married', 'Lucas Lefèvre', '+33123456780', NULL),
(14, 'Emma', 'Andersen', 'emma.andersen@prozilla.com', '+4512345678', '', '123 Oak St', 'Copenhagen', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Frederik Andersen', '+4598765432', NULL),
(15, 'Oliver', 'Kovač', 'oliver.kovac@prozilla.com', '+385989998877', '', '456 Maple Ave', 'Zagreb', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Petra Kovač', '+385989998876', NULL),
(16, 'Ava', 'Vasileva', 'ava.vasileva@prozilla.com', '+359888877766', '', '789 Elm St', 'Sofia', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Ivan Vasilev', '+359888877765', NULL),
(17, 'William', 'Bertaud', 'william.bertaud@prozilla.com', '+330101010101', '', '890 Cedar St', 'Paris', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Sophie Bertaud', '+330202020202', NULL),
(18, 'Sophia', 'Wagner', 'sophia.wagner@prozilla.com', '+4977777777', '', '567 Pine St', 'Munich', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Michael Wagner', '+4988888888', NULL),
(19, 'Liam', 'Janssen', 'liam.janssen@prozilla.com', '+31123456789', '', '123 Oak St', 'Amsterdam', '2022-01-01', NULL, 65000, 'Male', 'Single', 'Sophia Janssen', '+31123456788', NULL),
(20, 'Isabella', 'Ivanova', 'isabella.ivanova@prozilla.com', '+35912345678', '', '456 Maple Ave', 'Sofia', '2023-03-01', NULL, 60000, 'Female', 'Married', 'Dimitar Ivanov', '+35912345679', NULL),
(21, 'Noah', 'Andersen', 'noah.andersen@prozilla.com', '+4545454545', '', '789 Elm St', 'Copenhagen', '2024-05-10', NULL, 70000, 'Male', 'Divorced', 'Emma Andersen', '+4595959595', NULL),
(22, 'Olivia', 'Moreau', 'olivia.moreau@prozilla.com', '+33123456789', '', '890 Cedar St', 'Paris', '2021-12-15', NULL, 55000, 'Female', 'Single', 'Lucas Moreau', '+33121212121', NULL),
(23, 'Lucas', 'Novak', 'lucas.novak@prozilla.com', '+420987654321', '', '567 Pine St', 'Prague', '2023-08-20', NULL, 75000, 'Male', 'Married', 'Eva Novak', '+420987654322', NULL),
(24, 'Amelia', 'Vasquez', 'amelia.vasquez@prozilla.com', '+34678901234', '', '123 Oak St', 'Barcelona', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Carlos Vasquez', '+34678901235', NULL),
(25, 'Arthur', 'Kovalenko', 'arthur.kovalenko@prozilla.com', '+380987654321', '', '456 Maple Ave', 'Kyiv', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Anna Kovalenko', '+380987654322', NULL),
(26, 'Eva', 'Jansen', 'eva.jansen@prozilla.com', '+31123456789', '', '123 Oak St', 'Amsterdam', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Peter Jansen', '+31123456780', NULL),
(27, 'Max', 'Schmidt', 'max.schmidt@prozilla.com', '+49176123456', '', '456 Maple Ave', 'Berlin', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Anna Schmidt', '+49176123457', NULL),
(28, 'Lena', 'Dubois', 'lena.dubois@prozilla.com', '+33123456789', '', '789 Elm St', 'Paris', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Pierre Dubois', '+33123456780', NULL),
(29, 'Finn', 'Sørensen', 'finn.sorensen@prozilla.com', '+4523456789', '', '567 Pine St', 'Copenhagen', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Ida Sørensen', '+4523456790', NULL),
(30, 'Lara', 'Kovac', 'lara.kovac@prozilla.com', '+38598765432', '', '890 Cedar St', 'Zagreb', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Ivan Kovac', '+38598765433', NULL),
(31, 'Ella', 'Andersson', 'ella.andersson@prozilla.com', '+46701234567', '', '123 Oak St', 'Stockholm', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Erik Andersson', '+46701234568', NULL),
(32, 'Finn', 'Bachmann', 'finn.bachmann@prozilla.com', '+49123456789', '', '456 Maple Ave', 'Berlin', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Maria Bachmann', '+49123456780', NULL),
(33, 'Hannah', 'Carter', 'hannah.carter@prozilla.com', '+441234567890', '', '789 Elm St', 'London', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'David Carter', '+441234567891', NULL),
(34, 'Isaac', 'Delgado', 'isaac.delgado@prozilla.com', '+34678901234', '', '567 Pine St', 'Madrid', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Sofia Delgado', '+34678901235', NULL),
(35, 'Julia', 'Eriksson', 'julia.eriksson@prozilla.com', '+46789012345', '', '890 Cedar St', 'Stockholm', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Erik Eriksson', '+46789012346', NULL),
(36, 'Adam', 'Smith', 'adam.smith@prozilla.com', '+11234567890', '', '123 Oak St', 'New York', '2022-01-01', NULL, 65000, 'Male', 'Single', 'Mary Smith', '+11234567891', NULL),
(37, 'Sophie', 'Jones', 'sophie.jones@prozilla.com', '+44234567890', '', '456 Maple Ave', 'London', '2023-03-01', NULL, 60000, 'Female', 'Married', 'James Jones', '+44234567891', NULL),
(38, 'Emma', 'Garcia', 'emma.garcia@prozilla.com', '+34987654321', '', '789 Elm St', 'Madrid', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Pedro Garcia', '+34987654322', NULL),
(39, 'Daniel', 'Kovács', 'daniel.kovacs@prozilla.com', '+3612345678', '', '567 Pine St', 'Budapest', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Katalin Kovács', '+3612345679', NULL),
(40, 'Sophia', 'Müller', 'sophia.mueller@prozilla.com', '+49176123456', '', '890 Cedar St', 'Berlin', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Maximilian Müller', '+49176123457', NULL),
(41, 'Eva', 'Hoffmann', 'eva.hoffmann@prozilla.com', '+49234567890', '', '123 Oak St', 'Berlin', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Max Hoffmann', '+49234567891', NULL),
(42, 'Sophie', 'Gomes', 'sophie.gomes@prozilla.com', '+35123456789', '', '456 Maple Ave', 'Lisbon', '2023-03-01', NULL, 60000, 'Female', 'Married', 'Pedro Gomes', '+35123456780', NULL),
(43, 'Henry', 'Bakker', 'henry.bakker@prozilla.com', '+31765432109', '', '789 Elm St', 'Amsterdam', '2024-05-10', NULL, 70000, 'Male', 'Divorced', 'Anna Bakker', '+31765432110', NULL),
(44, 'Luna', 'Rossi', 'luna.rossi@prozilla.com', '+39012345678', '', '567 Pine St', 'Milan', '2021-12-15', NULL, 55000, 'Female', 'Single', 'Marco Rossi', '+39012345679', NULL),
(45, 'Sebastian', 'Kovač', 'sebastian.kovac@prozilla.com', '+38598765432', '', '890 Cedar St', 'Zagreb', '2023-08-20', NULL, 75000, 'Male', 'Married', 'Mia Kovač', '+38598765433', NULL),
(46, 'Sarah', 'Johnson', 'sarah.johnson@prozilla.com', '+19175555555', '', '123 Oak St', 'New York', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Michael Johnson', '+19175555556', NULL),
(47, 'Benjamin', 'Martinez', 'benjamin.martinez@prozilla.com', '+12135555557', '', '456 Maple Ave', 'Los Angeles', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Sophia Martinez', '+12135555558', NULL),
(48, 'Emma', 'Thompson', 'emma.thompson@prozilla.com', '+13125555559', '', '789 Elm St', 'Chicago', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'William Thompson', '+13125555560', NULL),
(49, 'Ethan', 'Garcia', 'ethan.garcia@prozilla.com', '+17865555561', '', '567 Pine St', 'Miami', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Olivia Garcia', '+17865555562', NULL),
(50, 'Sophia', 'Nguyen', 'sophia.nguyen@prozilla.com', '+14155555563', '', '890 Cedar St', 'San Francisco', '2023-08-20', NULL, 75000, 'Female', 'Married', 'James Nguyen', '+14155555564', NULL),
(51, 'Liam', 'Schmidt', 'liam.schmidt@prozilla.com', '+49175555555', '', '123 Oak St', 'Berlin', '2022-01-01', NULL, 65000, 'Male', 'Single', 'Michael Schmidt', '+49175555556', NULL),
(52, 'Ava', 'Vasiliev', 'ava.vasiliev@prozilla.com', '+78005555557', '', '456 Maple Ave', 'Moscow', '2023-03-01', NULL, 60000, 'Female', 'Married', 'Ivan Vasiliev', '+78005555558', NULL),
(53, 'Noah', 'Janssen', 'noah.janssen@prozilla.com', '+31105555559', '', '789 Elm St', 'Amsterdam', '2024-05-10', NULL, 70000, 'Male', 'Divorced', 'Eva Janssen', '+31105555560', NULL),
(54, 'Mia', 'Bernard', 'mia.bernard@prozilla.com', '+33105555561', '', '567 Pine St', 'Paris', '2021-12-15', NULL, 55000, 'Female', 'Single', 'Lucas Bernard', '+33105555562', NULL),
(55, 'Oliver', 'Hermansen', 'oliver.hermansen@prozilla.com', '+45715555563', '', '890 Cedar St', 'Copenhagen', '2023-08-20', NULL, 75000, 'Male', 'Married', 'Emma Hermansen', '+45715555564', NULL),
(56, 'Maria', 'Hernandez', 'maria.hernandez@prozilla.com', '+34900123456', '', '123 Carrer St', 'Barcelona', '2022-01-01', NULL, 60000, 'Female', 'Married', 'Alejandro Hernandez', '+34900123457', NULL),
(57, 'Matteo', 'Rossi', 'matteo.rossi@prozilla.com', '+390612345678', '', '456 Via Ave', 'Rome', '2023-03-01', NULL, 55000, 'Male', 'Single', 'Alessia Rossi', '+390612345679', NULL),
(58, 'Emma', 'Dubois', 'emma.dubois@prozilla.com', '+33123456789', '', '789 Rue St', 'Paris', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Thomas Dubois', '+33123456780', NULL),
(59, 'Oliver', 'Müller', 'oliver.mueller@prozilla.com', '+4916098765432', '', '890 Straße St', 'Berlin', '2021-12-15', NULL, 65000, 'Male', 'Single', 'Sophie Müller', '+4916098765433', NULL),
(60, 'Ava', 'Janssen', 'ava.janssen@prozilla.com', '+31781234567', '', '567 Gracht St', 'Amsterdam', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Lucas Janssen', '+31781234568', NULL),
(61, 'Liam', 'Andersen', 'liam.andersen@prozilla.com', '+4522555555', '', '123 Elm St', 'Copenhagen', '2022-01-01', NULL, 65000, 'Male', 'Single', 'Emma Andersen', '+4522555556', NULL),
(62, 'Matteo', 'Romano', 'matteo.romano@prozilla.com', '+3933555555', '', '456 Oak St', 'Rome', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Sofia Romano', '+3933555556', NULL),
(63, 'Eva', 'García', 'eva.garcia@prozilla.com', '+3491555555', '', '789 Maple Ave', 'Madrid', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Hugo García', '+3491555556', NULL),
(64, 'Oliver', 'Schmidt', 'oliver.schmidt@prozilla.com', '+4930555555', '', '567 Pine St', 'Berlin', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Emma Schmidt', '+4930555556', NULL),
(65, 'Ava', 'Dubois', 'ava.dubois@prozilla.com', '+3314555555', '', '890 Cedar St', 'Paris', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Louis Dubois', '+3314555556', NULL),
(66, 'Alice', 'Adams', 'alice.adams@prozilla.com', '+46701234567', '', '123 Oak St', 'Stockholm', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Eric Adams', '+46701234568', NULL),
(67, 'Benjamin', 'Bach', 'benjamin.bach@prozilla.com', '+31765432109', '', '456 Maple Ave', 'Amsterdam', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Peter Bach', '+31765432110', NULL),
(68, 'Catherine', 'Choi', 'catherine.choi@prozilla.com', '+33612345678', '', '789 Elm St', 'Paris', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Edward Choi', '+33612345679', NULL),
(69, 'Daniel', 'Diaz', 'daniel.diaz@prozilla.com', '+38598765432', '', '567 Pine St', 'Zagreb', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Ivan Diaz', '+38598765433', NULL),
(70, 'Emma', 'Eriksson', 'emma.eriksson@prozilla.com', '+49176123456', '', '890 Cedar St', 'Berlin', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Henry Eriksson', '+49176123457', NULL),
(71, 'Eleanor', 'Garcia', 'eleanor.garcia@prozilla.com', '+34987654321', '', '123 Oak St', 'Barcelona', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Carlos Garcia', '+34987654322', NULL),
(72, 'Henry', 'Schneider', 'henry.schneider@prozilla.com', '+49123456789', '', '456 Maple Ave', 'Berlin', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Anna Schneider', '+49123456790', NULL),
(73, 'Sophie', 'Janssen', 'sophie.janssen@prozilla.com', '+31765432109', '', '789 Elm St', 'Amsterdam', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Jan Janssen', '+31765432110', NULL),
(74, 'Oliver', 'Rossi', 'oliver.rossi@prozilla.com', '+390123456789', '', '567 Pine St', 'Rome', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Giulia Rossi', '+390123456780', NULL),
(75, 'Ava', 'Kovács', 'ava.kovacs@prozilla.com', '+3612345678', '', '890 Cedar St', 'Budapest', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Gábor Kovács', '+3612345679', NULL),
(76, 'Benjamin', 'Klein', 'benjamin.klein@prozilla.com', '+491234567890', '', '123 Birch St', 'Berlin', '2022-01-01', NULL, 65000, 'Male', 'Single', 'Lena Klein', '+491234567891', NULL),
(77, 'Charlotte', 'Andersen', 'charlotte.andersen@prozilla.com', '+4523456789', '', '456 Elm St', 'Copenhagen', '2023-03-01', NULL, 60000, 'Female', 'Married', 'Anders Andersen', '+4523456790', NULL),
(78, 'Daniel', 'Dubois', 'daniel.dubois@prozilla.com', '+3312345678', '', '789 Oak St', 'Paris', '2024-05-10', NULL, 70000, 'Male', 'Divorced', 'Marie Dubois', '+3312345679', NULL),
(79, 'Emma', 'Johansson', 'emma.johansson@prozilla.com', '+46701234567', '', '567 Cedar St', 'Stockholm', '2021-12-15', NULL, 55000, 'Female', 'Single', 'Oscar Johansson', '+46701234568', NULL),
(80, 'Henry', 'Mueller', 'henry.mueller@prozilla.com', '+491234567890', '', '123 Pine St', 'Munich', '2023-08-20', NULL, 75000, 'Male', 'Married', 'Anna Mueller', '+491234567891', NULL),
(81, 'Isabella', 'Moreau', 'isabella.moreau@prozilla.com', '+33612345678', '', '890 Oak St', 'Paris', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Luc Moreau', '+33612345679', NULL),
(82, 'Jacob', 'Hansen', 'jacob.hansen@prozilla.com', '+4523456789', '', '123 Elm St', 'Copenhagen', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Ida Hansen', '+4523456790', NULL),
(83, 'Lily', 'Vasileva', 'lily.vasileva@prozilla.com', '+35912345678', '', '456 Birch St', 'Sofia', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Nikolay Vasilev', '+35912345679', NULL),
(84, 'Michael', 'Garcia', 'michael.garcia@prozilla.com', '+34987654321', '', '789 Pine St', 'Barcelona', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Sofia Garcia', '+34987654322', NULL),
(85, 'Olivia', 'Kovács', 'olivia.kovacs@prozilla.com', '+3612345678', '', '890 Cedar St', 'Budapest', '2023-08-20', NULL, 75000, 'Female', 'Married', 'János Kovács', '+3612345679', NULL),
(86, 'Eva', 'Andersson', 'eva.andersson@prozilla.com', '+46701234567', '', '123 Oak St', 'Stockholm', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Erik Andersson', '+46701234568', NULL),
(87, 'Felix', 'Janssen', 'felix.janssen@prozilla.com', '+31765432109', '', '456 Maple Ave', 'Amsterdam', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Pieter Janssen', '+31765432110', NULL),
(88, 'Grace', 'Moreau', 'grace.moreau@prozilla.com', '+33612345678', '', '789 Elm St', 'Paris', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Emma Moreau', '+33612345679', NULL),
(89, 'Henry', 'Kovač', 'henry.kovac@prozilla.com', '+38598765432', '', '567 Pine St', 'Zagreb', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Ivan Kovač', '+38598765433', NULL),
(90, 'Isaac', 'Schneider', 'isaac.schneider@prozilla.com', '+49176123456', '', '890 Cedar St', 'Berlin', '2023-08-20', NULL, 75000, 'Male', 'Married', 'Hannah Schneider', '+49176123457', NULL),
(91, 'Julia', 'Hansen', 'julia.hansen@prozilla.com', '+4523456789', '', '123 Oak St', 'Copenhagen', '2022-01-01', NULL, 65000, 'Female', 'Single', 'Mads Hansen', '+4523456790', NULL),
(92, 'Kevin', 'García', 'kevin.garcia@prozilla.com', '+34987654321', '', '456 Maple Ave', 'Barcelona', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Sofia García', '+34987654322', NULL),
(93, 'Lily', 'Bakker', 'lily.bakker@prozilla.com', '+31765432109', '', '789 Elm St', 'Amsterdam', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Finn Bakker', '+31765432110', NULL),
(94, 'Mason', 'Vasilev', 'mason.vasilev@prozilla.com', '+35912345678', '', '567 Pine St', 'Sofia', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Milena Vasilev', '+35912345679', NULL),
(95, 'Nora', 'Müller', 'nora.mueller@prozilla.com', '+49176123456', '', '890 Cedar St', 'Munich', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Maximilian Müller', '+49176123457', NULL),
(96, 'Alice', 'Smith', 'alice.smith@prozilla.com', '+1234567890', '', '123 Oak St', 'Anytown', '2022-01-01', NULL, 65000, 'Female', 'Single', 'John Smith', '+1122334455', NULL),
(97, 'Ethan', 'Johnson', 'ethan.johnson@prozilla.com', '+1987654321', '', '456 Maple Ave', 'Othertown', '2023-03-01', NULL, 60000, 'Male', 'Married', 'Anna Johnson', '+1987654322', NULL),
(98, 'Sophie', 'Garcia', 'sophie.garcia@prozilla.com', '+3311223344', '', '789 Elm St', 'Sometown', '2024-05-10', NULL, 70000, 'Female', 'Divorced', 'Pierre Garcia', '+3344556677', NULL),
(99, 'Sebastian', 'Kim', 'sebastian.kim@prozilla.com', '+8222333444', '', '567 Pine St', 'Seoul', '2021-12-15', NULL, 55000, 'Male', 'Single', 'Soo Kim', '+8222333555', NULL),
(100, 'Julia', 'Müller', 'julia.mueller@prozilla.com', '+4912345678', '', '890 Cedar St', 'Berlin', '2023-08-20', NULL, 75000, 'Female', 'Married', 'Max Müller', '+4912345679', NULL),
(102, 'Mirza', 'Alamin', 'mirza@prozilla.com', NULL, 'mirza.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(103, 'Syedd', 'Foyez', 'foyez@prozilla.com', '3245', 'foyez.jpg', 'df', 'fd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `department_id` int(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `manager_id` int(255) DEFAULT NULL,
  `assign_team` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `client` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `start_date` text,
  `end_date` text,
  `description` text,
  `attachment` varchar(255) DEFAULT NULL,
  `work_status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_id`, `project_title`, `department_id`, `department`, `manager_id`, `assign_team`, `priority`, `client`, `price`, `start_date`, `end_date`, `description`, `attachment`, `work_status`) VALUES
(1, '1', 'UI/UX Enhancement', NULL, 'Designing', NULL, 'Creative Minds', 'High', 'TechVision Inc.', '5000', '2023-03-15', '2023-06-30', 'Enhancing UI/UX for the company’s flagship product.', 'TechVision.jpg', 'Completed'),
(2, '2', 'Mobile App Development', NULL, 'Development', NULL, 'InnovateX', 'High', 'DevTech Solutions', '8000', '2023-05-01', '2023-09-15', 'Developing a cutting-edge mobile app for digital payments.', 'DevTech.jpg', 'On Progress'),
(3, '3', 'Digital Marketing Campaign', NULL, 'Marketing', NULL, 'Digital Wizards', 'High', 'MarketGrowers Ltd.', '3000', '2023-04-10', '2023-07-20', 'Launching a digital marketing campaign for a new product line.', 'MarketGrowers.jpg', 'Pending'),
(4, '4', 'Employee Training Program APP UI', NULL, 'Human Resource', NULL, 'HR Champions', 'Low', 'TalentBoost Inc.', '2000', '2023-06-05', '2023-08-25', 'Conducting training sessions for skill development and retention.', 'TalentBoost.jpg', 'On Progress'),
(5, '5', 'Enterprise Resource Planning System', NULL, 'Managers', NULL, 'ExecuVate', 'High', 'StrategicSystems Ltd.', '6000', '2023-07-20', '2023-11-30', 'Implementing an ERP system for streamlined operations.', 'StrategicSystems.jpg', 'Pending'),
(6, '6', 'CRM Application Upgrade', NULL, 'Application', NULL, 'AppWise', 'Medium', 'DataWings Solutions', '4500', '2023-08-15', '2023-12-31', 'Upgrading CRM application for enhanced customer interactions.', 'DataWings.jpg', 'Completed'),
(7, '7', 'IT Infrastructure Modernization', NULL, 'IT', NULL, 'TechGenius', 'High', 'FutureTech Enterprises', '7500', '2023-09-10', '2024-01-15', 'Modernizing IT infrastructure for improved performance and security.', 'FutureTech.jpg', 'On Progress'),
(8, '8', 'Technical Documentation Revamp', NULL, 'Technical', NULL, 'TechSavvy', 'Medium', 'Techscribe Inc.', '4000', '2023-10-05', '2024-02-20', 'Revamping technical documentation for clearer user guidance.', 'Techscribe.jpg', 'Completed'),
(9, '9', 'Financial Reporting System Upgrade', NULL, 'Accounts', NULL, 'FinanceTech', 'High', 'NumbersUp Corporation', '6000', '2023-11-01', '2024-03-15', 'Upgrading the financial reporting system for faster insights.', 'NumbersUp.jpg', 'Pending'),
(10, '10', 'Customer Support Automation', NULL, 'Support', NULL, 'SupportAssist', 'Medium', 'HelpTech Solutions', '3500', '2023-12-01', '2024-04-30', 'Automating customer support processes for improved efficiency.', 'HelpTech.jpg', 'On Progress'),
(11, '11', 'User Interface Redesign', NULL, 'Designing', NULL, 'PixelPerfect', 'High', 'DesignSavvy Solutions', '5500', '2023-02-20', '2023-07-15', 'Revamping the user interface for improved aesthetics and usability.', 'DesignSavvy.jpg', 'Completed'),
(12, '12', 'Cloud Migration Strategy', NULL, 'IT', NULL, 'CloudMasters', 'High', 'CloudWorks Inc.', '8500', '2023-03-10', '2023-08-30', 'Developing a strategy for migrating applications to the cloud.', 'CloudWorks.jpg', 'On Progress'),
(13, '13', 'Social Media Marketing', NULL, 'Marketing', NULL, 'SocialSphere', 'Medium', 'MediaMagnet Solutions', '4000', '2023-04-05', '2023-09-25', 'Running a social media marketing campaign for brand awareness.', 'MediaMagnet.jpg', 'Pending'),
(14, '14', 'Employee Wellness Program', NULL, 'Human Resource', NULL, 'WellBeing Crew', 'Low', 'HealthFirst Enterprises', '2500', '2023-05-01', '2023-10-20', 'Implementing a wellness program for employee health.', 'HealthFirst.jpg', 'On Progress'),
(15, '15', 'E-commerce Platform Upgrade', NULL, 'Development', NULL, 'E-commerceGenius', 'High', 'WebMarket Solutions', '7000', '2023-06-05', '2023-11-25', 'Upgrading the e-commerce platform for enhanced user experience.', 'WebMarket.jpg', 'Pending'),
(16, '16', 'Data Security Audit', NULL, 'Security', NULL, 'Securitech', 'High', 'SecureData Systems', '6000', '2023-07-10', '2023-12-31', 'Conducting a security audit to identify vulnerabilities.', 'SecureData.jpg', 'On Progress'),
(17, '17', 'AI-driven Customer Support', NULL, 'Support', NULL, 'AIAssist', 'Medium', 'SupportAI Technologies', '4500', '2023-08-15', '2024-01-31', 'Implementing AI for customer support automation.', 'SupportAI.jpg', 'Completed'),
(18, '18', 'Software Documentation Review', NULL, 'Technical', NULL, 'TechWrite', 'Medium', 'TechDocs Inc.', '4000', '2023-09-20', '2024-03-15', 'Reviewing and updating software documentation for accuracy.', 'TechDocs.jpg', 'Pending'),
(19, '19', 'Digital Innovation Research', NULL, 'Innovation', NULL, 'DigitalVision', 'High', 'FutureThink Labs', '8000', '2023-10-25', '2024-04-30', 'Researching digital innovation trends for future initiatives.', 'FutureThink.jpg', 'On Progress'),
(20, '20', 'Financial Forecasting Tool', NULL, 'Accounts', NULL, 'FinanceForecast', 'High', 'ForecastTech Solutions', '6500', '2023-11-30', '2024-06-15', 'Developing a tool for financial forecasting and analysis.', 'ForecastTech.jpg', 'Completed'),
(21, '21', 'Graphic Design Suite Upgrade', NULL, 'Designing', NULL, 'DesignInnovate', 'High', 'ArtTech Solutions', '5500', '2023-02-20', '2023-08-15', 'Upgrading graphic design software suite for advanced features.', 'ArtTech.jpg', 'Completed'),
(22, '22', 'IoT Integration Project', NULL, 'Development', NULL, 'IoTBuilders', 'High', 'SmartSystems Inc.', '8500', '2023-03-10', '2023-09-30', 'Integrating IoT technology into existing products.', 'SmartSystems.jpg', 'On Progress'),
(23, '23', 'Content Marketing Campaign', NULL, 'Marketing', NULL, 'ContentCrafters', 'Medium', 'Contentify Solutions', '4000', '2023-04-05', '2023-10-25', 'Creating a content marketing strategy for online engagement.', 'Contentify.jpg', 'Pending'),
(24, '24', 'Diversity & Inclusion Initiative', NULL, 'Human Resource', NULL, 'DiverseWorkforce', 'Low', 'InclusiveCorp', '2500', '2023-05-01', '2023-11-20', 'Launching initiatives to promote diversity and inclusion.', 'InclusiveCorp.jpg', 'On Progress'),
(25, '25', 'Software Automation Framework', NULL, 'IT', NULL, 'AutomationGenius', 'High', 'Automatech Solutions', '7000', '2023-06-05', '2023-12-30', 'Developing a framework for software test automation.', 'Automatech.jpg', 'Pending'),
(26, '26', 'Network Security Enhancement', NULL, 'Security', NULL, 'SecureNetworks', 'High', 'NetSecure Technologies', '6000', '2023-07-10', '2024-01-31', 'Enhancing network security for better protection against threats.', 'NetSecure.jpg', 'On Progress'),
(27, '27', 'Remote Work Collaboration Tools', NULL, 'Support', NULL, 'RemoteConnect', 'Medium', 'VirtualLink Solutions', '4500', '2023-08-15', '2024-02-28', 'Implementing tools to facilitate collaboration in remote teams.', 'VirtualLink.jpg', 'In Progress'),
(28, '28', 'Technical Skills Training Program', NULL, 'Technical', NULL, 'SkillBuilders', 'Medium', 'TechEd Academy', '4000', '2023-09-20', '2024-04-15', 'Conducting training programs to enhance technical skills.', 'TechEd.jpg', 'Pending'),
(29, '29', 'Cloud-Based AI Solutions', NULL, 'AI', NULL, 'CloudAI Innovators', 'High', 'AI Cloud Systems', '8000', '2023-10-25', '2024-05-30', 'Developing AI solutions using cloud-based technologies.', 'AICloud.jpg', 'On Progress'),
(30, '30', 'Financial Risk Assessment Tool', NULL, 'Accounts', NULL, 'RiskAssure', 'High', 'FinancialGuard Solutions', '6500', '2023-11-30', '2024-07-15', 'Creating a tool for assessing financial risks and vulnerabilities.', 'FinancialGuard.jpg', 'Completed'),
(31, '31', 'UI/UX Optimization Project', NULL, 'Designing', NULL, 'UI Visionaries', 'High', 'TechTrends Solutions', '5500', '2023-02-20', '2023-09-15', 'Optimizing user interface and experience for increased engagement.', 'TechTrends.jpg', 'Completed'),
(32, '32', 'AI Chatbot Development', NULL, 'Development', NULL, 'Chatbot Masters', 'High', 'BotWorks Inc.', '8500', '2023-03-10', '2023-10-30', 'Building an AI-powered chatbot for customer support.', 'BotWorks.jpg', 'On Progress'),
(33, '33', 'Social Media Advertising Campaign', NULL, 'Marketing', NULL, 'Social Trendsetters', 'Medium', 'AdVantage Media', '4000', '2023-04-05', '2023-11-25', 'Executing targeted social media ad campaigns.', 'AdVantage.jpg', 'Pending'),
(34, '34', 'Employee Training & Development', NULL, 'Human Resource', NULL, 'SkillGrowers', 'Low', 'TalentHub Solutions', '2500', '2023-05-01', '2023-12-20', 'Training and development programs for employee growth.', 'TalentHub.jpg', 'On Progress'),
(35, '35', 'Cloud Infrastructure Enhancement', NULL, 'IT', NULL, 'CloudOps', 'High', 'CloudTech Innovations', '7000', '2023-06-05', '2024-01-15', 'Improving and scaling cloud infrastructure.', 'CloudTech.jpg', 'Pending'),
(36, '36', 'Cybersecurity Incident Response Plan', NULL, 'Security', NULL, 'CyberShield', 'High', 'SecureCyber Systems', '6000', '2023-07-10', '2024-02-28', 'Creating a plan to respond to cybersecurity incidents.', 'SecureCyber.jpg', 'On Progress'),
(37, '37', 'Remote Work Collaboration Platform', NULL, 'Support', NULL, 'RemoteConnect', 'Medium', 'VirtualWork Solutions', '4500', '2023-08-15', '2024-03-10', 'Developing a platform for remote team collaboration.', 'VirtualWork.jpg', 'Completed'),
(38, '38', 'Technical Documentation Automation', NULL, 'Technical', NULL, 'DocAutomate', 'Medium', 'TechDocs Solutions', '4000', '2023-09-20', '2024-04-05', 'Automating technical documentation processes.', 'TechDocs.jpg', 'Pending'),
(39, '39', 'Predictive Analytics Solutions', NULL, 'Data Science', NULL, 'DataInsights', 'High', 'InsightfulData Tech', '8000', '2023-10-25', '2024-05-15', 'Developing predictive analytics solutions for data-driven insights.', 'InsightfulData.jpg', 'On Progress'),
(40, '40', 'Financial Reporting Dashboard', NULL, 'Accounts', NULL, 'FinanceVision', 'High', 'FinancialTech Solutions', '6500', '2023-11-30', '2024-06-20', 'Creating a dashboard for real-time financial reporting.', 'FinancialTech.jpg', 'Completed'),
(41, '41', 'Brand Identity Redesign', NULL, 'Designing', NULL, 'BrandBuilders', 'High', 'DigitalBrand Solutions', '5500', '2023-02-20', '2023-09-15', 'Revamping brand identity for a fresh market appeal.', 'DigitalBrand.jpg', 'Completed'),
(42, '42', 'Blockchain Integration Project', NULL, 'Development', NULL, 'BlockTech Innovators', 'High', 'ChainTech Solutions', '8500', '2023-03-10', '2023-10-30', 'Integrating blockchain technology into existing systems.', 'ChainTech.jpg', 'On Progress'),
(43, '43', 'Influencer Marketing Campaign', NULL, 'Marketing', NULL, 'InfluenceMasters', 'Medium', 'SocialSway Agency', '4000', '2023-04-05', '2023-11-25', 'Executing a campaign leveraging social media influencers.', 'SocialSway.jpg', 'Pending'),
(44, '44', 'Leadership Training Program', NULL, 'Human Resource', NULL, 'LeadershipForge', 'Low', 'LeadTech Institute', '2500', '2023-05-01', '2023-12-20', 'Training programs focused on leadership development.', 'LeadTech.jpg', 'On Progress'),
(45, '45', 'Cloud Security Assessment', NULL, 'IT', NULL, 'CloudSecures', 'High', 'CloudGuard Systems', '7000', '2023-06-05', '2024-01-15', 'Assessing security measures for cloud-based systems.', 'CloudGuard.jpg', 'Pending'),
(46, '46', 'Penetration Testing Initiative', NULL, 'Security', NULL, 'PenTestExperts', 'High', 'SecureTests Inc.', '6000', '2023-07-10', '2024-02-28', 'Conducting penetration tests for system vulnerabilities.', 'SecureTests.jpg', 'On Progress'),
(47, '47', 'Virtual Collaboration Platform', NULL, 'Support', NULL, 'VirtualTeamUp', 'Medium', 'VirtuWorks Solutions', '4500', '2023-08-15', '2024-03-10', 'Developing a virtual collaboration platform for teams.', 'VirtuWorks.jpg', 'Completed'),
(48, '48', 'Software Bug Fixing Initiative', NULL, 'Technical', NULL, 'BugBusters', 'Medium', 'CodeFix Solutions', '4000', '2023-09-20', '2024-04-05', 'Identifying and fixing bugs in existing software.', 'CodeFix.jpg', 'Pending'),
(49, '49', 'Machine Learning Algorithms', NULL, 'AI', NULL, 'MLGeniuses', 'High', 'DataMind Innovations', '8000', '2023-10-25', '2024-05-15', 'Developing advanced machine learning algorithms.', 'DataMind.jpg', 'On Progress'),
(50, '50', 'Financial Analysis Tool Development', NULL, 'Accounts', NULL, 'FinanceForecast', 'High', 'MoneyMinds Inc.', '6500', '2023-11-30', '2024-06-20', 'Developing a tool for financial analysis and forecasting.', 'MoneyMinds.jpg', 'Completed'),
(51, '51', 'Mobile App UI Refinement', NULL, 'Designing', NULL, 'MobileDesigners', 'High', 'AppVision Solutions', '5500', '2023-02-20', '2023-09-15', 'Enhancing the UI of a mobile application for better user experience.', 'AppVision.jpg', 'Completed'),
(52, '52', 'IoT Solutions Development', NULL, 'Development', NULL, 'IoTInnovate', 'High', 'SmartConnect Inc.', '8500', '2023-03-10', '2023-10-30', 'Creating innovative solutions using IoT technology.', 'SmartConnect.jpg', 'On Progress'),
(53, '53', 'Content Creation Strategy', NULL, 'Marketing', NULL, 'ContentCreators', 'Medium', 'DigitalMarketers Co.', '4000', '2023-04-05', '2023-11-25', 'Developing a strategy for engaging content creation.', 'DigitalMarketers.jpg', 'Pending'),
(54, '54', 'Employee Engagement Initiative', NULL, 'Human Resource', NULL, 'EngagementBoosters', 'Low', 'PeopleFirst Solutions', '2500', '2023-05-01', '2023-12-20', 'Implementing programs to boost employee engagement.', 'PeopleFirst.jpg', 'On Progress'),
(55, '55', 'Cloud Migration Planning', NULL, 'IT', NULL, 'CloudShifters', 'High', 'DataCloud Innovations', '7000', '2023-06-05', '2024-01-15', 'Planning and strategizing the migration of systems to the cloud.', 'DataCloud.jpg', 'Pending'),
(56, '56', 'Cybersecurity Training Program', NULL, 'Security', NULL, 'CyberGuardians', 'High', 'SecureNet Solutions', '6000', '2023-07-10', '2024-02-28', 'Conducting training sessions to enhance cybersecurity awareness.', 'SecureNet.jpg', 'On Progress'),
(57, '57', 'Remote Collaboration Tools', NULL, 'Support', NULL, 'RemoteHelpers', 'Medium', 'CollabWorks Inc.', '4500', '2023-08-15', '2024-03-10', 'Developing tools to facilitate remote collaboration among teams.', 'CollabWorks.jpg', 'Completed'),
(58, '58', 'Technical Documentation Update', NULL, 'Technical', NULL, 'TechDocsUpdate', 'Medium', 'UpdateTech Solutions', '4000', '2023-09-20', '2024-04-05', 'Updating technical documentation for accuracy and relevance.', 'UpdateTech.jpg', 'Pending'),
(59, '59', 'AI-driven Predictive Analysis', NULL, 'AI', NULL, 'AIAnalytics', 'High', 'FutureAI Solutions', '8000', '2023-10-25', '2024-05-15', 'Implementing AI models for predictive data analysis.', 'FutureAI.jpg', 'On Progress'),
(60, '60', 'Financial Performance Dashboard', NULL, 'Accounts', NULL, 'FinanceInsights', 'High', 'InsightTech Inc.', '6500', '2023-11-30', '2024-06-20', 'Creating a dashboard for real-time financial performance monitoring.', 'InsightTech.jpg', 'Completed'),
(61, '61', 'AI-driven Data Analysis Tool', NULL, 'Data Science', NULL, 'AIAnalytics', 'High', 'DataInsight Innovations', '7500', '2023-12-05', '2024-07-10', 'Developing an AI-powered tool for comprehensive data analysis.', 'DataInsight.jpg', 'On Progress'),
(62, '62', 'Automated Marketing Solutions', NULL, 'Marketing', NULL, 'AutoMarketeers', 'Medium', 'TechAdvisors Co.', '5000', '2024-01-15', '2024-08-20', 'Implementing automated solutions for marketing campaigns.', 'TechAdvisors.jpg', 'Pending'),
(63, '63', 'Cloud-Based Project Management', NULL, 'IT', NULL, 'CloudManagers', 'High', 'ProjectTech Solutions', '8500', '2024-02-20', '2024-09-25', 'Implementing a cloud-based project management system.', 'ProjectTech.jpg', 'On Progress'),
(64, '64', 'Digital Transformation Strategy', NULL, 'Business Strategy', NULL, 'DigitalTransformers', 'High', 'TransformTech Inc.', '9000', '2024-03-10', '2024-10-30', 'Developing a strategy for digital transformation initiatives.', 'TransformTech.jpg', 'On Progress'),
(65, '65', 'E-commerce User Experience Revamp', NULL, 'Designing', NULL, 'EcomDesigners', 'High', 'EcomTech Solutions', '6500', '2024-04-05', '2024-11-25', 'Enhancing the user experience for an e-commerce platform.', 'EcomTech.jpg', 'Pending'),
(66, '66', 'Employee Engagement Platform Development', NULL, 'Human Resource', NULL, 'EngageTech', 'Medium', 'EmployeeConnect Inc.', '5500', '2024-05-01', '2024-12-20', 'Building a platform to enhance employee engagement.', 'EmployeeConnect.jpg', 'On Progress'),
(67, '67', 'Financial Data Visualization Tool', NULL, 'Finance', NULL, 'DataVizExperts', 'High', 'VisualizeTech Solutions', '7000', '2024-06-05', '2025-01-15', 'Developing a tool for visualizing financial data.', 'VisualizeTech.jpg', 'Pending'),
(68, '68', 'IT Security Incident Response Plan', NULL, 'Security', NULL, 'SecurityResponse', 'High', 'TechSecure Solutions', '7500', '2024-07-10', '2025-02-28', 'Creating a plan for responding to IT security incidents.', 'TechSecure.jpg', 'On Progress'),
(69, '69', 'Mobile Application Security Assessment', NULL, 'IT', NULL, 'MobileSecurity', 'High', 'SecureApps Inc.', '6000', '2024-08-15', '2025-03-10', 'Conducting security assessments for mobile applications.', 'SecureApps.jpg', 'Completed'),
(70, '70', 'Predictive Maintenance System Development', NULL, 'Maintenance', NULL, 'PredictiveMasters', 'Medium', 'MaintainTech Solutions', '5500', '2024-09-20', '2025-04-05', 'Developing a system for predictive equipment maintenance.', 'MaintainTech.jpg', 'Pending'),
(71, '71', 'Real-time Data Analytics Platform', NULL, 'Data Science', NULL, 'RealTimeAnalytics', 'High', 'DataVision Innovations', '8000', '2024-10-25', '2025-05-15', 'Developing a platform for real-time data analysis.', 'DataVision.jpg', 'On Progress'),
(72, '72', 'AI-Powered Customer Support System', NULL, 'Customer Support', NULL, 'AICustomerSupport', 'High', 'SupportGenius Solutions', '8500', '2024-11-30', '2025-06-20', 'Implementing an AI-based system for customer support.', 'SupportGenius.jpg', 'Completed'),
(73, '73', 'Blockchain Authentication Solutions', NULL, 'Security', NULL, 'BlockchainSecurity', 'High', 'AuthenticTech Inc.', '9000', '2025-01-01', '2025-07-01', 'Developing solutions for blockchain-based authentication.', 'AuthenticTech.jpg', 'On Progress'),
(74, '74', 'Automated Inventory Management System', NULL, 'Operations', NULL, 'AutoInventory', 'Medium', 'InventoryTech Solutions', '5500', '2025-02-05', '2025-08-01', 'Implementing an automated system for inventory management.', 'InventoryTech.jpg', 'Pending'),
(75, '75', 'Cloud Data Migration Strategy', NULL, 'IT', NULL, 'CloudMigrate', 'High', 'DataMigrate Solutions', '7000', '2025-03-10', '2025-09-01', 'Developing a strategy for migrating data to the cloud.', 'DataMigrate.jpg', 'On Progress'),
(76, '76', 'Digital Marketing Automation Tool', NULL, 'Marketing', NULL, 'MarketingAutomate', 'Medium', 'Digitalize Solutions', '6000', '2025-04-15', '2025-10-01', 'Creating a tool for automating digital marketing processes.', 'Digitalize.jpg', 'Completed'),
(77, '77', 'Employee Skill Development Program', NULL, 'Human Resource', NULL, 'SkillDevelopers', 'High', 'SkillUp Inc.', '7500', '2025-05-20', '2025-11-01', 'Implementing a program for enhancing employee skills.', 'SkillUp.jpg', 'On Progress'),
(78, '78', 'Financial Fraud Detection System', NULL, 'Finance', NULL, 'FraudDetect', 'High', 'FraudGuard Solutions', '8000', '2025-06-25', '2025-12-01', 'Developing a system for detecting financial fraud.', 'FraudGuard.jpg', 'Completed'),
(79, '79', 'IT Infrastructure Automation Solution', NULL, 'IT', NULL, 'ITAutomation', 'Medium', 'AutomateTech Inc.', '6500', '2025-07-30', '2026-01-01', 'Implementing automation solutions for IT infrastructure.', 'AutomateTech.jpg', 'Pending'),
(80, '80', 'Predictive Sales Analytics Tool', NULL, 'Sales', NULL, 'SalesPredict', 'High', 'SalesVision Solutions', '7500', '2025-08-30', '2026-02-01', 'Developing a tool for predictive sales analytics.', 'SalesVision.jpg', 'On Progress'),
(81, '81', 'AI Chatbot Integration', NULL, 'IT', NULL, 'AIChatIntegration', 'High', 'ChatAI Solutions', '7000', '2026-01-05', '2026-07-01', 'Integrating AI chatbots into existing systems for improved customer interaction.', 'ChatAI.jpg', 'Pending'),
(82, '82', 'Automated Supply Chain Management', NULL, 'Operations', NULL, 'AutoSupplyChain', 'High', 'SupplyChainTech Inc.', '8500', '2026-02-10', '2026-08-01', 'Implementing automated solutions for efficient supply chain management.', 'SupplyChainTech.jpg', 'On Progress'),
(83, '83', 'Blockchain-based Authentication Framework', NULL, 'Security', NULL, 'BlockchainAuth', 'High', 'SecureBlock Solutions', '9000', '2026-03-15', '2026-09-01', 'Developing a framework using blockchain for secure authentication.', 'SecureBlock.jpg', 'Completed'),
(84, '84', 'Cloud Data Storage Optimization', NULL, 'IT', NULL, 'CloudOptimize', 'High', 'DataOptima Solutions', '7500', '2026-04-20', '2026-10-01', 'Optimizing cloud storage solutions for better performance and efficiency.', 'DataOptima.jpg', 'On Progress'),
(85, '85', 'Digital Marketing Analytics Platform', NULL, 'Marketing', NULL, 'MarketingAnalytics', 'Medium', 'AnalyticsTech Inc.', '6000', '2026-05-25', '2026-11-01', 'Developing a platform for analyzing digital marketing campaign performance.', 'AnalyticsTech.jpg', 'Pending'),
(86, '86', 'Employee Wellness App Development', NULL, 'Human Resource', NULL, 'WellnessApp', 'High', 'WellnessTech Solutions', '8000', '2026-06-30', '2026-12-01', 'Creating an app to promote employee well-being and health.', 'WellnessTech.jpg', 'On Progress'),
(87, '87', 'Financial Risk Management System', NULL, 'Finance', NULL, 'RiskManagement', 'High', 'RiskGuard Solutions', '8500', '2026-07-05', '2027-01-01', 'Developing a system to manage financial risks and uncertainties.', 'RiskGuard.jpg', 'Completed'),
(88, '88', 'IT Process Automation Tool', NULL, 'IT', NULL, 'ITProcessAutomation', 'Medium', 'AutomationTech Inc.', '6500', '2026-08-10', '2027-02-01', 'Implementing a tool to automate routine IT processes and tasks.', 'AutomationTech.jpg', 'On Progress'),
(89, '89', 'Predictive Customer Behavior Analysis', NULL, 'Sales', NULL, 'PredictiveSales', 'High', 'CustomerInsights Solutions', '7500', '2026-09-15', '2027-03-01', 'Developing algorithms for predicting customer behavior patterns.', 'CustomerInsights.jpg', 'Pending'),
(90, '90', 'Robotic Process Automation Implementation', NULL, 'Operations', NULL, 'RPAImplementation', 'High', 'RoboTech Solutions', '9000', '2026-10-20', '2027-04-01', 'Implementing robotic process automation to streamline operational tasks.', 'RoboTech.jpg', 'On Progress'),
(91, '91', 'AI-powered Virtual Assistant', NULL, 'IT', NULL, 'AIVirtualAssistant', 'High', 'VirtualAI Solutions', '8000', '2027-10-26', '2027-08-21', 'Developing an AI-driven virtual assistant for diverse functionalities.', 'VirtualAI.jpg', 'On Progress'),
(92, '92', 'Automated Inventory Tracking System', NULL, 'Operations', NULL, 'AutoInventoryTracking', 'High', 'InventoryTech Inc.', '8500', '2027-02-28', '2027-08-01', 'Implementing a system for automated tracking and management of inventory.', 'InventoryTech.jpg', 'Pending'),
(93, '93', 'Blockchain-based Supply Chain Verification', NULL, 'Security', NULL, 'BlockchainSupplyChain', 'High', 'VerifiedChain Solutions', '9000', '2027-03-30', '2027-09-01', 'Developing a blockchain-based system for supply chain verification.', 'VerifiedChain.jpg', 'On Progress'),
(94, '94', 'Cloud Infrastructure Cost Optimization', NULL, 'IT', NULL, 'CloudCostOptimize', 'High', 'CostSaver Solutions', '7500', '2027-04-30', '2027-10-01', 'Optimizing cloud infrastructure costs for better efficiency.', 'CostSaver.jpg', 'Completed'),
(95, '95', 'Digital Marketing Performance Dashboard', NULL, 'Marketing', NULL, 'MarketingDashboard', 'Medium', 'PerformanceMetrics Inc.', '6000', '2027-05-30', '2027-11-01', 'Creating a dashboard to track digital marketing campaign performance.', 'PerformanceMetrics.jpg', 'Pending'),
(96, '96', 'Employee Productivity Enhancement Program', NULL, 'Human Resource', NULL, 'ProductivityBoost', 'High', 'ProductivityTech Solutions', '8000', '2027-06-30', '2027-12-01', 'Implementing programs to enhance employee productivity and efficiency.', 'ProductivityTech.jpg', 'On Progress'),
(97, '97', 'Financial Portfolio Management Tool', NULL, 'Finance', NULL, 'PortfolioManagement', 'High', 'PortfolioTech Solutions', '8500', '2027-07-30', '2028-01-01', 'Developing a tool for managing financial portfolios and investments.', 'PortfolioTech.jpg', 'Completed'),
(98, '98', 'IT Service Desk Automation System', NULL, 'IT', NULL, 'ServiceDeskAutomation', 'Medium', 'ServiceTech Inc.', '6500', '2027-08-30', '2028-02-01', 'Implementing automation for IT service desk operations.', 'ServiceTech.jpg', 'On Progress'),
(99, '99', 'Predictive Sales Forecasting Model', NULL, 'Sales', NULL, 'SalesForecast', 'High', 'SalesPredict Solutions', '7500', '2027-09-30', '2028-03-01', 'Developing a model to predict sales trends and patterns.', 'SalesPredict.jpg', 'Pending'),
(100, '100', 'Robotic Automation Process Integration', NULL, 'Operations', NULL, 'RoboAutomation', 'High', 'RoboTech Solutions', '9000', '2027-10-30', '2028-04-01', 'Integrating robotic automation processes for streamlined operations.', 'RoboTech.jpg', 'On Progress'),
(101, '324', 'Test', NULL, 'Designing', NULL, 'Team 01', 'High', 'Client 01', '2345', '01-01-2024', '08-01-2024', 'fg', 'Asset 7.png', 'Pending'),
(102, '345', 'testty', NULL, 'Designing', NULL, 'Team 01', 'High', 'Client 01', '345', '01-01-2024', '18-01-2024', 'Mirza', 'stock-vector-fluid-gradient-background-abstract-d-background-liquid-paints-banner-or-sign-design-vector-2279167341.jpg', 'Pending'),
(103, '103', 'Cloud Infrastructure Cost Optimization', NULL, 'IT', NULL, 'CloudCostOptimize', 'High', 'CostSaver Solutions', '7500', '2027-05-30', '2027-10-01', 'Optimizing cloud infrastructure costs for better efficiency.', 'CostSaver.jpg', 'Completed'),
(104, '104', 'Cloud Infrastructure Cost Optimization', NULL, 'IT', NULL, 'CloudCostOptimize', 'High', 'CostSaver Solutions', '7500', '2027-05-30', '2027-10-01', 'Optimizing cloud infrastructure costs for better efficiency.', 'CostSaver.jpg', 'Completed'),
(105, '98', 'IT Service Desk Automation System', NULL, 'IT', NULL, 'ServiceDeskAutomation', 'Medium', 'ServiceTech Inc.', '6500', '2027-05-30', '2028-02-01', 'Implementing automation for IT service desk operations.', 'ServiceTech.jpg', 'On Progress'),
(106, '91', 'AI-powered Virtual Assistant', NULL, 'IT', NULL, 'AIVirtualAssistant', 'High', 'VirtualAI Solutions', '8000', '2027-09-25', '2027-07-01', 'Developing an AI-driven virtual assistant for diverse functionalities.', 'VirtualAI.jpg', 'Completed'),
(107, '6', 'CRM Application Upgrade', NULL, 'Application', NULL, 'AppWise', 'Medium', 'DataWings Solutions', '4500', '2023-12-15', '2023-12-31', 'Upgrading CRM application for enhanced customer interactions.', 'DataWings.jpg', 'Completed'),
(108, '2', 'Mobile App Development', NULL, 'Development', NULL, 'InnovateX', 'High', 'DevTech Solutions', '8000', '2023-05-01', '2023-09-15', 'Developing a cutting-edge mobile app for digital payments.', 'DevTech.jpg', 'On Progress'),
(110, '555', 'random', NULL, 'Development', NULL, 'Team 01', 'High', 'Client 01', '1000', '01-01-2024', '01-01-2024', 'gjyfhfvjdd', 'devtech-featured-post-ptayhk28pxmgyom40l19qsx1n0ft56e0h566yd62nw.jpg', 'Pending'),
(111, '3Frttr', 'Test', NULL, 'Designing', NULL, '', 'High', '', NULL, '16-01-2024', '25-01-2024', 'test', 'mockup-of-a-grocery-bag-filled-with-vegetables-41749-r-el2.png', 'Pending'),
(113, 'new', 'uiux', NULL, 'Designing', NULL, '', 'Medium', '', NULL, '16-01-2024', '23-01-2024', 'ne ui', 'devtech-featured-post-ptayhk28pxmgyom40l19qsx1n0ft56e0h566yd62nw.jpg', 'Pending'),
(114, '3444', 'Test', NULL, 'Designing', NULL, NULL, 'High', '', NULL, '20-01-2024', '30-01-2024', 'TEST', 'prozzila-Project-Management-System (1).png', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(255) NOT NULL,
  `project_name` varchar(255) DEFAULT NULL,
  `card_id` int(255) DEFAULT NULL,
  `task_name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `priority` enum('High','Medium','Low') DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `total_assigned` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_name`, `card_id`, `task_name`, `description`, `priority`, `start_date`, `due_date`, `status`, `total_assigned`) VALUES
(1, 'UI/UX Enhancement', 1, 'ewfgrehtrjyewgrt', 'fb', 'High', '2024-01-12', '2024-01-09', NULL, 2),
(2, 'Mobile App Development', NULL, 'test', 'f', 'High', '2024-01-04', '2024-01-02', NULL, 1),
(3, 'Employee Training Program APP UI', NULL, 'testd', 'f', 'High', '2024-01-19', '2024-01-09', 'Complete', NULL),
(4, 'Digital Marketing Campaign', 6, 'UI Design', 'Add UI Design', 'High', '2024-01-14', '2024-01-24', NULL, 2),
(5, 'User Interface Redesign', 4, 'Mobile Development', 'Android Mobile Development', 'High', '2024-01-15', '2024-02-01', NULL, 2),
(6, 'Software Documentation Review', NULL, 'App Development', 'App Dev', 'Medium', '2024-01-16', '2024-01-24', NULL, 1),
(7, 'Diversity & Inclusion Initiative', NULL, 'App Development', 'ttt', 'High', '2024-01-16', '2024-01-16', NULL, NULL),
(8, 'Technical Skills Training Program', NULL, 'uiux', 'mobile ui', 'High', '2024-01-16', '2024-01-23', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
CREATE TABLE `team` (
  `id` int(11) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `department_id`, `name`) VALUES
(1, 0, 'Creative Minds'),
(2, 0, 'InnovateX'),
(3, 0, 'Digital Wizards'),
(4, 0, 'HR Champions'),
(5, 0, 'ExecuVate'),
(6, 0, 'AppWise'),
(7, 0, 'TechGenius'),
(8, 0, 'TechSavvy'),
(9, 0, 'FinanceTech'),
(10, 0, 'SupportAssist'),
(11, 0, 'PixelPerfect'),
(12, 0, 'CloudMasters'),
(13, 0, 'SocialSphere'),
(14, 0, 'WellBeing Crew'),
(15, 0, 'E-commerceGenius'),
(16, 0, 'Securitech'),
(17, 0, 'AIAssist'),
(18, 0, 'TechWrite'),
(19, 0, 'DigitalVision'),
(20, 0, 'FinanceForecast'),
(21, 0, 'DesignInnovate'),
(22, 0, 'IoTBuilders'),
(23, 0, 'ContentCrafters'),
(24, 0, 'DiverseWorkforce'),
(25, 0, 'AutomationGenius'),
(26, 0, 'SecureNetworks'),
(27, 0, 'RemoteConnect'),
(28, 0, 'SkillBuilders'),
(29, 0, 'CloudAI Innovators'),
(30, 0, 'RiskAssure'),
(31, 0, 'UI Visionaries'),
(32, 0, 'Chatbot Masters'),
(33, 0, 'Social Trendsetters'),
(34, 0, 'SkillGrowers'),
(35, 0, 'CloudOps'),
(36, 0, 'CyberShield'),
(37, 0, 'DocAutomate'),
(38, 0, 'DataInsights'),
(39, 0, 'FinanceVision'),
(40, 0, 'BrandBuilders'),
(41, 0, 'BlockTech Innovators'),
(42, 0, 'InfluenceMasters'),
(43, 0, 'LeadershipForge'),
(44, 0, 'CloudSecures'),
(45, 0, 'PenTestExperts'),
(46, 0, 'VirtualTeamUp'),
(47, 0, 'BugBusters'),
(48, 0, 'MLGeniuses'),
(49, 0, 'MobileDesigners'),
(50, 0, 'IoTInnovate'),
(51, 0, 'ContentCreators'),
(52, 0, 'EngagementBoosters'),
(53, 0, 'CloudShifters'),
(54, 0, 'CyberGuardians'),
(55, 0, 'RemoteHelpers'),
(56, 0, 'TechDocsUpdate'),
(57, 0, 'AIAnalytics'),
(58, 0, 'FinanceInsights'),
(59, 0, 'AutoMarketeers'),
(60, 0, 'CloudManagers'),
(61, 0, 'DigitalTransformers'),
(62, 0, 'EcomDesigners'),
(63, 0, 'EngageTech'),
(64, 0, 'DataVizExperts'),
(65, 0, 'SecurityResponse'),
(66, 0, 'MobileSecurity'),
(67, 0, 'PredictiveMasters'),
(68, 0, 'RealTimeAnalytics'),
(69, 0, 'AICustomerSupport'),
(70, 0, 'BlockchainSecurity'),
(71, 0, 'AutoInventory'),
(72, 0, 'CloudMigrate'),
(73, 0, 'MarketingAutomate'),
(74, 0, 'SkillDevelopers'),
(75, 0, 'FraudDetect'),
(76, 0, 'ITAutomation'),
(77, 0, 'SalesPredict'),
(78, 0, 'AIChatIntegration'),
(79, 0, 'AutoSupplyChain'),
(80, 0, 'BlockchainAuth'),
(81, 0, 'CloudOptimize'),
(82, 0, 'MarketingAnalytics'),
(83, 0, 'WellnessApp'),
(84, 0, 'RiskManagement'),
(85, 0, 'ITProcessAutomation'),
(86, 0, 'PredictiveSales'),
(87, 0, 'RPAImplementation'),
(88, 0, 'AIVirtualAssistant'),
(89, 0, 'AutoInventoryTracking'),
(90, 0, 'BlockchainSupplyChain'),
(91, 0, 'CloudCostOptimize'),
(92, 0, 'MarketingDashboard'),
(93, 0, 'ProductivityBoost'),
(94, 0, 'PortfolioManagement'),
(95, 0, 'ServiceDeskAutomation'),
(96, 0, 'SalesForecast'),
(97, 0, 'RoboAutomation'),
(98, 0, 'Team 01');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

DROP TABLE IF EXISTS `upload`;
CREATE TABLE `upload` (
  `id` int(255) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `upload_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text,
  `project_name` varchar(255) DEFAULT NULL,
  `task_name` varchar(255) DEFAULT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `user_id` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `completed_tasks`
--
ALTER TABLE `completed_tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`),
  ADD UNIQUE KEY `department_code` (`department_code`),
  ADD KEY `manager_id` (`manager_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `old_complete`
--
ALTER TABLE `old_complete`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_manager_id` (`manager_id`),
  ADD KEY `fk_department_id` (`department_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `cards`
--
ALTER TABLE `cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `completed_tasks`
--
ALTER TABLE `completed_tasks`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `old_complete`
--
ALTER TABLE `old_complete`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=746;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `permission_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `upload`
--
ALTER TABLE `upload`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `fk_department_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_manager_id` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
